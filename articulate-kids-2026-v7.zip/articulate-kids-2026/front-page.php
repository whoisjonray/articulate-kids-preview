<?php if (!defined('ABSPATH')) exit; get_header(); ?>
<!-- HERO -->
<header class="hero spots">
  <span class="blob b1"></span><span class="blob b2"></span>
  <div class="wrap hero-grid">
    <div>
      <span class="pill rise">No waiting lists · No referral needed · Ages 20 months–18</span>
      <h1 class="rise r2">We find out what's <span class="coral">really going on</span> — and what to do about it.</h1>
      <p class="lede rise r3">The first clinic in the UK to bring together speech and language therapy, brain and gut testing, and <b>Lights On™ light therapy</b> — so nothing about your child gets missed.</p>
      <div class="hero-cta rise r3">
        <button class="btn btn-p">Book an appointment</button>
        <button class="btn btn-w">Take the free 2-minute check</button>
      </div>
      <div class="hero-stats rise r4">
        <div class="hstat"><b>25 years</b><span>Specialist experience</span></div>
        <div class="hstat"><b>40,000+</b><span>Consultations</span></div>
        <div class="hstat"><b>Exclusive UK</b><span>Lab testing provider</span></div>
      </div>
    </div>
    <div class="hero-photo rise r3">
      <div class="squircle"><img src="https://articulatekids.co.uk/wp-content/uploads/2026/01/young-kid-playing-with-fidget-home-1024x681.jpg" alt="A young child at home during a session"></div>
      <div class="sticker s-a"><span class="em">🗣️</span><div><b>"He's talking."</b><span>after years of waiting</span></div></div>
      <div class="sticker s-b"><span class="stars">★★★★★</span><div><b>Real families</b><span>real results</span></div></div>
    </div>
  </div>
</header>

<!-- PROOF -->
<div class="proof">
  <div class="wrap proof-in">
    <span>The only clinic of its <b>kind in the UK</b></span><span class="sep">•</span>
    <span>Exclusive UK <b>lab-testing provider</b></span><span class="sep">•</span>
    <span><b>Expert witness</b>, SEND tribunals</span><span class="sep">•</span>
    <span>As seen in the <b>Daily Telegraph</b></span>
  </div>
</div>

<!-- THE SIGNS -->
<section class="signs" id="signs">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">Start here</span>
      <h2 class="sec-h">Is your child showing any of these signs?</h2>
      <p class="sec-sub">Some families come with a diagnosis. Others are still waiting, or just have a feeling something isn't quite right. Both are welcome. Even one sign is enough to get in touch.</p>
    </div>
    <div class="acc">
      <div class="acc-g open">
        <button class="acc-head" onclick="tg(this)">Talking and understanding <span class="cnt">10 signs</span><span class="tog">+</span></button>
        <div class="acc-body"><div class="chips">
          <span class="chip">Not talking yet</span><span class="chip">Slow to pick up new words</span><span class="chip">Said words, then lost them — regression</span><span class="chip">Understands everything, but struggles to speak</span><span class="chip">Talking seems a huge effort for them</span><span class="chip">Finds it hard to follow spoken instructions</span><span class="chip">Chats to themselves, but can't hold a conversation</span><span class="chip">Doesn't respond to their name</span><span class="chip">Older and still non-speaking</span><span class="chip">Uses an AAC device, but progress has stalled</span>
        </div></div>
      </div>
      <div class="acc-g">
        <button class="acc-head" onclick="tg(this)">Mood, attention and regulation <span class="cnt">9 signs</span><span class="tog">+</span></button>
        <div class="acc-body"><div class="chips">
          <span class="chip">Mood dysregulation — big emotional ups and downs</span><span class="chip">Can't calm down once upset</span><span class="chip">Struggles to attend and listen — even one-to-one</span><span class="chip">Easily distracted</span><span class="chip">In their own world</span><span class="chip">Tunes out — you say their name several times</span><span class="chip">Hyperactive — always on the go</span><span class="chip">Can't sit still</span><span class="chip">Hyper one minute, zoned out the next</span>
        </div></div>
      </div>
      <div class="acc-g">
        <button class="acc-head" onclick="tg(this)">Eating, sleep and the body <span class="cnt">7 signs</span><span class="tog">+</span></button>
        <div class="acc-body"><div class="chips">
          <span class="chip">Picky eating</span><span class="chip">Effortful chewing, coughing or gagging at meals</span><span class="chip">Drooling or dribbling</span><span class="chip">Grinding their teeth</span><span class="chip">Snoring or noisy breathing at night</span><span class="chip">Sleep problems</span><span class="chip">Bowel problems — loose stools or constipation</span>
        </div></div>
      </div>
      <div class="acc-g">
        <button class="acc-head" onclick="tg(this)">Sensory and movement <span class="cnt">11 signs</span><span class="tog">+</span></button>
        <div class="acc-body"><div class="chips">
          <span class="chip">Covers their ears</span><span class="chip">Struggles with sensory overload</span><span class="chip">Overstimulated or understimulated</span><span class="chip">Bothered by clothing labels, seams or textures</span><span class="chip">Seeks big sensations — crashing, squeezing, spinning</span><span class="chip">Doesn't notice pain, hunger or needing the toilet</span><span class="chip">Stimming</span><span class="chip">Toe walking</span><span class="chip">Lines up toys</span><span class="chip">Poor balance — trips and falls</span><span class="chip">Slow with motor tasks — dressing, cutlery, catching</span>
        </div></div>
      </div>
      <div class="acc-g">
        <button class="acc-head" onclick="tg(this)">School and the journey so far <span class="cnt">4 signs</span><span class="tog">+</span></button>
        <div class="acc-body"><div class="chips">
          <span class="chip">Handwriting is a real effort</span><span class="chip">Struggles with reading and writing</span><span class="chip">Has had a lot of therapy, but progress is slow</span><span class="chip">Their EHCP isn't meeting their needs — or you're still fighting to get one</span>
        </div></div>
      </div>
    </div>
    <div class="signs-close">
      <p>If even one of these sounds familiar, we can help.</p>
      <div class="qz">
        <h3>Not sure where you fit? Take the free 2-minute check.</h3>
        <p>Tell us where to send it and we'll email you a personalised starting point, based on the signs you recognise.</p>
        <div class="row">
          <input class="field" type="text" placeholder="Your first name">
          <input class="field" type="email" placeholder="Your email address">
          <button class="btn btn-p">Start</button>
        </div>
        <p class="fine">This is us — where do we start? · No spam, just your next step.</p>
      </div>
    </div>
  </div>
</section>

<!-- WHO WE HELP -->
<section class="who" id="who">
  <div class="wrap">
    <span class="sec-eye">Who we help</span>
    <h2 class="sec-h">This is what we do, and all we do.</h2>
    <p class="sec-sub">For 25 years, we've specialised in the children who don't fit neatly into anyone's boxes.</p>
    <p class="who-body"><span class="muted">If your child has puzzled every professional so far, they'll be in familiar company here. You'll find everything we help with in the list further down the page.</span></p>
    <div class="pills">
      <span class="pillx">25 YEARS EXPERIENCE</span>
      <span class="pillx">40,000+ APPOINTMENTS</span>
      <span class="pillx">PUBLISHED AUTHOR</span>
      <span class="pillx">SEND TRIBUNAL EXPERT WITNESS</span>
      <span class="pillx">DAILY TELEGRAPH</span>
    </div>
  </div>
</section>

<!-- WHY WE'RE DIFFERENT -->
<section class="why">
  <span class="blob"></span>
  <div class="wrap in">
    <span class="sec-eye">Why we're different</span>
    <h2 class="sec-h">When nothing else has worked, something hasn't been looked at.</h2>
    <p class="why-body">Most clinics look at one thing at a time — the speech, or the behaviour, or the diet. We look at how it all fits together: brain, gut, senses and communication. We also use testing that isn't available anywhere else in the UK. Quite often, that's where the answer turns out to have been.</p>
    <blockquote class="why-quote">"Every child makes sense, once you know where to look."</blockquote>
    <div class="why-stats">
      <div class="why-stat"><b>25 years</b><span>of specialist practice</span></div>
      <div class="why-stat"><b>40,000+</b><span>appointments with children</span></div>
      <div class="why-stat"><b>1 team</b><span>brain, gut, speech and light, together</span></div>
    </div>
  </div>
</section>

<!-- MEET HULYA -->
<section class="founder" id="founder">
  <div class="wrap">
    <span class="sec-eye">Meet the founder</span>
    <p class="f-mission">"Every child deserves to be understood. That's the whole mission — it always has been."</p>
    <div class="f-grid">
      <div class="f-photo">
        <div class="squircle"><img src="https://articulatekids.co.uk/wp-content/uploads/2025/07/2F1A9461-1-2-683x1024.jpg" alt="Hulya Mehmet, founder of Articulate Kids" style="object-position:center top"></div>
        <div class="sticker"><span class="em">🦒</span><div><b>Founder</b><span>25 years' experience</span></div></div>
      </div>
      <div>
        <h2 class="sec-h" style="max-width:none">Hulya Mehmet</h2>
        <div class="f-role">Founder · Consultant Speech and Language Therapist · BSc (Hons), MRCSLT</div>
        <div class="f-bio">
          <p>Hulya has spent 25 years working with children who communicate differently — more than 40,000 appointments, across every kind of profile.</p>
          <p>She's a published author, a regular expert witness in SEND tribunals, and one of the UK's leading voices on children's communication and neurodiversity.</p>
          <p>She's also a parent who has sat on the other side of the table — waiting for answers about her own children. <b>That's why this clinic looks harder, and looks everywhere.</b></p>
          <p>Hulya is the first speech and language therapist in the UK to bring light therapy into paediatric neurodevelopmental care, drawing on specialist training and extensive hands-on experience. It's delivered as part of a carefully designed clinical plan — safe, effective use depends on the right protocol for each child, not the equipment alone.</p>
        </div>
        <div class="f-pills">
          <span>AUTHOR, "WHY ISN'T MY CHILD TALKING?"</span>
          <span>SEND TRIBUNAL EXPERT WITNESS</span>
          <span>DAILY TELEGRAPH</span>
          <span>BRAINZ MAGAZINE</span>
        </div>
        <button class="btn btn-w" style="box-shadow:0 8px 22px rgba(58,47,40,.1)">More about Hulya</button>
      </div>
    </div>
  </div>
</section>

<!-- EARLY NEEDS TRACKER (book + lead magnet) -->
<section class="book">
  <div class="wrap book-grid">
    <div class="book-cover">
      <img src="https://articulatekids.co.uk/wp-content/uploads/2025/07/hulya-book-website-final.png" alt="Why Isn't My Child Talking? by Hulya Mehmet">
    </div>
    <div class="book-txt">
      <span class="sec-eye">Free download</span>
      <h2 class="sec-h">Early Needs Tracker</h2>
      <p class="book-lede">Use this easy 50-question tracker from Hulya's book, <em>Why Isn't My Child Talking?</em> to spot early communication and sensory needs, follow your child's progress, and share clear info with GPs, health visitors, nurseries, and therapists. Try it now and get the full tracker by email.</p>
      <form class="tk-form" onsubmit="return false">
        <input class="field" type="text" placeholder="Your First Name">
        <input class="field" type="email" placeholder="Your Email">
        <button class="btn btn-p">Send Me the Free Tracker</button>
      </form>
    </div>
  </div>
</section>

<!-- WHAT WE OFFER -->
<section class="offer" id="offer">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">What we offer</span>
      <h2 class="sec-h">Start with one thing, or the full picture.</h2>
      <p class="sec-sub">Most families start with an assessment and then a block of therapy. You're welcome to start anywhere.</p>
    </div>
    <div class="offer-grid">
      <div class="oc">
        <div class="oi"><svg viewBox="0 0 24 24" class="ic"><path d="M9 3v2M15 3v2M6 8h12a2 2 0 012 2v9a2 2 0 01-2 2H6a2 2 0 01-2-2v-9a2 2 0 012-2z"/><path d="M8 13h5M8 17h8"/></svg></div>
        <h3>Assessment</h3>
        <p>A thorough, unhurried look at how your child is getting on. For some families, this is all that's needed.</p>
      </div>
      <div class="oc">
        <div class="oi"><svg viewBox="0 0 24 24" class="ic"><path d="M8 10h8M8 14h5"/><path d="M21 12a8 8 0 01-8 8H7l-4 3v-7A8 8 0 0121 12z"/></svg></div>
        <h3>Speech and language therapy</h3>
        <p>Expert therapy, shaped around your child — including children who don't use words yet.</p>
      </div>
      <div class="oc">
        <div class="oi"><svg viewBox="0 0 24 24" class="ic"><path d="M9 3h6M10 3v5l-5 9a2 2 0 002 3h10a2 2 0 002-3l-5-9V3"/><path d="M8 15h8"/></svg></div>
        <h3>Brain and gut testing</h3>
        <p>Laboratory testing not available anywhere else in the UK. We recommend it — we never require it.</p>
      </div>
      <div class="oc">
        <div class="oi"><svg viewBox="0 0 24 24" class="ic"><circle cx="12" cy="12" r="4"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M19 5l-2 2M7 17l-2 2"/></svg></div>
        <a href="/photobiomodulation-light-therapy-children/" style="text-decoration:none"><h3>Lights On<span class="tm">™</span> Pathways Method</h3>
        <p>Our light therapy (photobiomodulation) programme — gentle, pain-free sessions as part of your child's wider plan, professionally delivered, never a take-home device.</p><span class="go" style="color:var(--coral)">Learn about photobiomodulation →</span></a>
      </div>
      <div class="oc">
        <div class="oi"><svg viewBox="0 0 24 24" class="ic"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M9 8h6M9 12h6M9 16h4"/></svg></div>
        <h3>EHCP and tribunal reports</h3>
        <p>Expert reports for EHCPs and SEND tribunals, from one of the UK's most experienced expert witnesses.</p>
      </div>
      <div class="oc soft">
        <div class="oi"><svg viewBox="0 0 24 24" class="ic"><path d="M12 3a9 9 0 100 18 9 9 0 000-18z"/><path d="M9.5 9a2.5 2.5 0 015 0c0 1.5-2.5 2-2.5 4M12 17h.01"/></svg></div>
        <h3>Not sure yet?</h3>
        <p>Join Hulya's free live talk for parents — no booking required.</p>
        <a class="go" href="#webinar">See the free webinar →</a>
      </div>
    </div>
  </div>
</section>

<!-- CONDITIONS WE TREAT (SEO links) -->
<section class="cond" id="conditions">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">Conditions we treat</span>
      <h2 class="sec-h">The big things, the little things, and everything in between.</h2>
    </div>
    <div class="cond-grid">
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/autism/"><h3>Autism <span class="ar">→</span></h3><p>Communication, social interaction and sensory needs.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/adhd/"><h3>ADHD <span class="ar">→</span></h3><p>Attention, language and the link between them.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/early-years-late-talkers/"><h3>Late talkers <span class="ar">→</span></h3><p>Early support in the years that matter most.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/speech-sounds-development/"><h3>Speech delay <span class="ar">→</span></h3><p>Helping children say sounds clearly.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/language-development/"><h3>Language delay <span class="ar">→</span></h3><p>Building understanding, words and sentences.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/developmental-verbal-dyspraxia/"><h3>Verbal dyspraxia <span class="ar">→</span></h3><p>When planning and producing speech is the struggle.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/stuttering/"><h3>Stammering <span class="ar">→</span></h3><p>Gentle, evidence-based support for fluency.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/voice-disorders-dysphonia/"><h3>Voice disorders (dysphonia) <span class="ar">→</span></h3><p>Hoarseness, strain, or an unusual voice.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/dyslexia-and-working-memory/"><h3>Dyslexia and working memory <span class="ar">→</span></h3><p>Language skills and memory strategies.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/dysphagia/"><h3>Dysphagia <span class="ar">→</span></h3><p>Safe, calmer eating, drinking and swallowing.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/conditions-help/behaviour/"><h3>Behaviour <span class="ar">→</span></h3><p>When behaviour is communication.</p></a>
      <a class="cc" href="https://articulatekids.co.uk/ehcp-tribunal-expert/"><h3>EHCP and tribunals <span class="ar">→</span></h3><p>Expert assessment and reports.</p></a>
    </div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section class="how">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">How it works</span>
      <h2 class="sec-h">What happens when you get in touch.</h2>
    </div>
    <div class="how-grid">
      <div class="hw"><div class="n">1</div><h3>Get in touch</h3><p>Call, email, or book online. No referral needed.</p></div>
      <div class="hw"><div class="n">2</div><h3>We talk</h3><p>A short call to understand your child and choose the right starting point.</p></div>
      <div class="hw"><div class="n">3</div><h3>First visit</h3><p>A calm, friendly assessment at Harley Street or Orpington.</p></div>
      <div class="hw"><div class="n">4</div><h3>Your plan</h3><p>A clear written report and a plan made just for your child.</p></div>
    </div>
  </div>
</section>

<!-- REASSURANCE -->
<section class="reassure">
  <div class="wrap re-grid">
    <div class="re"><div class="ri"><svg viewBox="0 0 24 24" class="ic"><path d="M12 21s-7-4.5-7-10a4 4 0 017-2.5A4 4 0 0119 11c0 5.5-7 10-7 10z"/></svg></div><div><h3>No referral needed</h3><p>Being worried is reason enough to get in touch.</p></div></div>
    <div class="re"><div class="ri"><svg viewBox="0 0 24 24" class="ic"><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/></svg></div><div><h3>Child-led and calm</h3><p>Sessions go at your child's pace, not ours.</p></div></div>
    <div class="re"><div class="ri"><svg viewBox="0 0 24 24" class="ic"><path d="M3 9l9-6 9 6v10a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><path d="M9 21v-6h6v6"/></svg></div><div><h3>One team, one plan</h3><p>Everything happens under one roof, so nothing falls between the gaps.</p></div></div>
  </div>
</section>

<!-- WEBINAR -->
<section class="web" id="webinar">
  <span class="blob"></span>
  <div class="wrap web-grid">
    <div>
      <span class="sec-eye">Free · Online · First Thursday of every month</span>
      <h2 class="sec-h">Not sure yet? That's fine — start here.</h2>
      <p class="web-body">Hulya gives a free online talk for parents once a month — plain English, honest answers, and time for your questions at the end. Many parents join to learn more about brain and gut testing, or our Lights On™ light therapy programme.</p>
      <div class="web-month">📅 This month: <em>Brain, gut and behaviour — the links that get missed</em></div>
    </div>
    <div class="wcard">
      <span class="free">FREE</span>
      <h3>Save your seat</h3>
      <p>Pop your details below and we'll send the joining link before the next talk.</p>
      <input class="field" type="text" placeholder="First name">
      <input class="field" type="email" placeholder="Email address">
      <button class="btn btn-p">Save my seat</button>
      <p class="fine">Can't make it? Register anyway and we'll send the recording.</p>
    </div>
  </div>
</section>

<!-- ARTICLES (SEO) -->
<section class="arts">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">Expert guidance for parents</span>
      <h2 class="sec-h">Honest answers to your biggest questions.</h2>
    </div>
    <div class="arts-grid">
      <a class="art" href="https://articulatekids.co.uk/are-we-failing-girls-why-autism-often-goes-unrecognised-in-females/">
        <div class="thumb"><img src="https://articulatekids.co.uk/wp-content/uploads/2025/07/helena-lopes-CD5EJQbtDa8-unsplash-1024x683.jpg" alt=""></div>
        <div class="ab"><div class="cat">Autism</div><h3>Are we failing girls? Why autism often goes unrecognised in females</h3><span class="go">Read more →</span></div>
      </a>
      <a class="art" href="https://articulatekids.co.uk/the-alarming-decline-in-childrens-motor-skills-why-movement-matters-more-than-ever/">
        <div class="thumb"><img src="https://articulatekids.co.uk/wp-content/uploads/2025/07/christian-bowen-C_0CMAE412s-unsplash-1024x678.jpg" alt=""></div>
        <div class="ab"><div class="cat">Development</div><h3>The alarming decline in children's motor skills, and why movement matters</h3><span class="go">Read more →</span></div>
      </a>
      <a class="art" href="https://articulatekids.co.uk/how-diet-affects-your-childs-speech-language-and-attention-a-speech-therapists-guide/">
        <div class="thumb"><img src="https://articulatekids.co.uk/wp-content/uploads/2026/01/young-kid-playing-with-fidget-home-1024x681.jpg" alt=""></div>
        <div class="ab"><div class="cat">Gut &amp; brain</div><h3>How diet affects your child's speech, language and attention</h3><span class="go">Read more →</span></div>
      </a>
    </div>
    <div class="arts-all"><a class="btn btn-w" href="https://articulatekids.co.uk/articles/">Read all articles</a></div>
  </div>
</section>

<!-- FAQ -->
<section class="faq" id="faq">
  <div class="wrap">
    <div class="center" style="margin-bottom:40px">
      <span class="sec-eye">Before you book</span>
      <h2 class="sec-h" style="margin-inline:auto">Your questions, answered.</h2>
    </div>
    <div class="faq-wrap">
      <div class="fi"><button class="fq" onclick="tf(this)">My child doesn't have a diagnosis. Can we still come?<span class="t">+</span></button><div class="fa"><p>Yes. You don't need a diagnosis or a referral. If you're worried about your child, that's enough.</p></div></div>
      <div class="fi"><button class="fq" onclick="tf(this)">How old does my child need to be?<span class="t">+</span></button><div class="fa"><p>We work with children aged 20 months to 18 years.</p></div></div>
      <div class="fi"><button class="fq" onclick="tf(this)">What actually is light therapy?<span class="t">+</span></button><div class="fa"><p>Light therapy — also called photobiomodulation — uses gentle, low-level light to stimulate cells. It's non-invasive, pain-free, and each session takes just a few minutes. We call our programme Lights On™. It's a clinical treatment, delivered in-clinic as part of your child's plan — not a device you'd use at home.</p><p>Hulya is the first speech and language therapist in the UK to introduce it into paediatric neurodevelopmental care, drawing on specialist training and extensive hands-on experience. It's delivered as part of a carefully designed clinical plan, separately from your child's speech and language therapy — safe, effective use depends on the right protocol for each child, not the equipment alone, which is why this isn't something to attempt at home.</p></div></div>
      <div class="fi"><button class="fq" onclick="tf(this)">Do I have to book the lab tests or Lights On™?<span class="t">+</span></button><div class="fa"><p>No. Nothing beyond an assessment is required to access our service. We recommend the testing and light therapy where relevant — we never require them.</p></div></div>
      <div class="fi"><button class="fq" onclick="tf(this)">Can I speak to someone before I book?<span class="t">+</span></button><div class="fa"><p>Yes. Call 020 3858 0765 or email info@articulatekids.co.uk. Our team gets back to you within 3 working days.</p></div></div>
    </div>
  </div>
</section>

<!-- FINAL -->
<section class="final">
  <div class="wrap">
    <div class="card"><span class="blob"></span>
      <div class="in">
        <h2>Whenever you're ready, we're here.</h2>
        <p>Book online or give us a call. There's no long waiting list, no referral needed, and no pressure either way.</p>
        <button class="btn btn-p" style="background:var(--amber)">Book an appointment</button>
        <div class="final-info"><span>📞 020 3858 0765</span><span>✉️ info@articulatekids.co.uk</span><span>Orpington &amp; Harley Street, London</span></div>
      </div>
    </div>
  </div>
</section>

<!-- FOOTER (SEO link block) -->
<?php get_footer(); ?>

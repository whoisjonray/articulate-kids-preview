<?php
/**
 * Homepage.
 *
 * Rebuilt 2026-08-09 to Hulya's revised flow. Two things drive the layout:
 * her section order (practical banner → hero → Assess/Plan/Treat/Progress →
 * founder → webinar → concerns → expertise → book → short lower half → CTA),
 * and her request to reduce sensory load, since most visiting parents are
 * autistic or ADHD. The decorative blobs, spot textures, floating stickers and
 * entrance/bobbing animations are gone, headings are smaller, and coral is now
 * reserved for calls to action rather than used as a general accent.
 */
if (!defined('ABSPATH')) exit;
get_header(); ?>

<!-- 1. PRACTICAL BAR -->
<section class="strip">
  <div class="wrap">
    <div class="strip-facts">
      <span>No waiting lists</span><i>·</i>
      <span>No referral needed</span><i>·</i>
      <span>Ages 18 months to 18 years</span>
    </div>
    <div class="strip-where">
      Orpington, Kent &nbsp;·&nbsp; Harley Street, London &nbsp;·&nbsp; Appointments in clinic and online
    </div>
  </div>
</section>

<!-- 2. HERO — headline has to be the first thing above the fold -->
<header class="hero">
  <div class="wrap">
    <h1>We find out why your child is stuck, and help them reach their potential.</h1>
    <p class="hero-explain">We look at the whole child, work out what may be causing the difficulties, and create the right individual plan to help your child make meaningful progress.</p>
    <div class="hero-cta"><a class="btn btn-p" href="/book-an-appointment/">Book an assessment</a></div>
  </div>
</header>

<!-- 2b. AGE-RANGE BAND — slim, sits directly under the promise -->
<section class="ages">
  <div class="wrap">
    <img src="<?php echo esc_url(get_stylesheet_directory_uri()); ?>/assets/img/age-range-banner.jpg"
         alt="Children of all ages, from toddlers to teenagers, who we work with at Articulate Kids"
         width="1600" height="737" fetchpriority="high">
    <p class="ages-cap">Speech and language difficulties, attention and behaviour, nervous system regulation, sensory differences, motor and coordination difficulties, restricted eating, sleep, learning difficulties and problems at school.</p>
  </div>
</section>

<!-- 3. OUR DIFFERENCE -->
<section class="diff">
  <div class="wrap">
    <h2 class="sec-h center-h">Because the problem you see isn't always the whole problem.</h2>
    <ol class="path">
      <li>
        <span class="path-n">1</span>
        <h3>Assess</h3>
        <p>Understand what's happening</p>
      </li>
      <li>
        <span class="path-n">2</span>
        <h3>Plan</h3>
        <p>Work out what your child needs</p>
      </li>
      <li>
        <span class="path-n">3</span>
        <h3>Treat</h3>
        <p>Put the right plan into action</p>
      </li>
      <li>
        <span class="path-n">4</span>
        <h3>Progress</h3>
        <p>Focus on meaningful change</p>
      </li>
    </ol>
    <p class="diff-usp">We're the only clinic in the UK bringing speech and language therapy together with brain and gut laboratory testing and the Lights On<span class="tm">&trade;</span> Method, and the exclusive UK provider of that testing.</p>
  </div>
</section>

<!-- 4. HULYA -->
<section class="founder" id="founder">
  <div class="wrap f-grid">
    <div class="f-photo">
      <img src="<?php echo esc_url(get_stylesheet_directory_uri()); ?>/assets/img/hulya-book-portrait.jpg"
           alt="Hulya Mehmet, founder of Articulate Kids, holding her book Why Isn't My Child Talking?"
           width="560" height="900" loading="lazy">
    </div>
    <div class="f-txt">
      <span class="sec-eye">Meet the founder</span>
      <h2 class="sec-h">25+ years of experience understanding the child behind the symptoms.</h2>
      <p>Hulya Mehmet is a Consultant Speech and Language Therapist, BSc (Hons), MRCSLT. She has spent more than 25 years with children who communicate differently, across more than 40,000 appointments, and she's a published author and a regular expert witness in SEND tribunals.</p>
      <p>She's also a parent who has sat on the other side of the table, waiting for answers about her own children. That's why this clinic looks harder, and looks everywhere.</p>
      <blockquote>&ldquo;Every child makes sense, once you know where to look.&rdquo;</blockquote>
      <div class="cred">
        <span>25+ years' experience</span><i>·</i>
        <span>40,000+ appointments</span><i>·</i>
        <span>Published author</span><i>·</i>
        <span>SEND expert witness</span>
      </div>
      <a class="lnk" href="/about/">More about Hulya &rarr;</a>
    </div>
  </div>
</section>

<!-- 5. WEBINAR -->
<section class="web" id="webinar">
  <div class="wrap">
    <span class="sec-eye">Free monthly parent webinar</span>
    <h2 class="sec-h center-h">Trying to work out what's going on with your child? Join Hulya live.</h2>
    <div class="web-meta">Free &nbsp;·&nbsp; Live online &nbsp;·&nbsp; Every month</div>
    <form class="web-form" onsubmit="return false">
      <input class="field" type="text" placeholder="First name" aria-label="First name">
      <input class="field" type="email" placeholder="Email address" aria-label="Email address">
      <button class="btn btn-p">Save my free place</button>
    </form>
    <p class="web-fine">Can't make it live? Register anyway and we'll send you the recording.</p>
  </div>
</section>

<!-- 6. WHAT'S HAPPENING WITH YOUR CHILD -->
<section class="signs" id="signs">
  <div class="wrap">
    <h2 class="sec-h center-h">What's happening with your child?</h2>
    <p class="sec-sub center-h">One of these may sound familiar, or several. Either is reason enough to get in touch.</p>
    <div class="acc">
      <div class="acc-g">
        <button class="acc-head" onclick="tg(this)">Talking &amp; understanding<span class="tog">+</span></button>
        <div class="acc-body"><ul>
          <li>Not talking yet, or slow to pick up new words</li>
          <li>Said words, then lost them</li>
          <li>Understands everything, but struggles to speak</li>
          <li>Finds it hard to follow spoken instructions</li>
          <li>Doesn't respond to their name</li>
          <li>Older and still non-speaking, or using AAC with progress stalled</li>
        </ul></div>
      </div>
      <div class="acc-g">
        <button class="acc-head" onclick="tg(this)">Attention, mood &amp; behaviour<span class="tog">+</span></button>
        <div class="acc-body"><ul>
          <li>Big emotional ups and downs, hard to calm once upset</li>
          <li>Struggles to attend and listen, even one to one</li>
          <li>Easily distracted, or in their own world</li>
          <li>Always on the go, or hyper one minute and zoned out the next</li>
        </ul></div>
      </div>
      <div class="acc-g">
        <button class="acc-head" onclick="tg(this)">Regulation &amp; nervous system<span class="tog">+</span></button>
        <div class="acc-body"><ul>
          <li>Goes from nought to sixty with little warning</li>
          <li>Meltdowns or shutdowns that take a long time to pass</li>
          <li>Constantly on alert, or unusually switched off</li>
          <li>Struggles with change and transitions</li>
        </ul></div>
      </div>
      <div class="acc-g">
        <button class="acc-head" onclick="tg(this)">Eating, sleep &amp; the body<span class="tog">+</span></button>
        <div class="acc-body"><ul>
          <li>Restricted or very picky eating</li>
          <li>Effortful chewing, coughing or gagging at meals</li>
          <li>Drooling, teeth grinding, or noisy breathing at night</li>
          <li>Sleep problems</li>
          <li>Bowel problems, loose stools or constipation</li>
        </ul></div>
      </div>
      <div class="acc-g">
        <button class="acc-head" onclick="tg(this)">Sensory, motor &amp; movement<span class="tog">+</span></button>
        <div class="acc-body"><ul>
          <li>Covers their ears, or struggles with sensory overload</li>
          <li>Bothered by clothing labels, seams or textures</li>
          <li>Seeks big sensations, crashing, squeezing, spinning</li>
          <li>Doesn't notice pain, hunger or needing the toilet</li>
          <li>Toe walking, poor balance, trips and falls</li>
          <li>Slow with dressing, cutlery or catching</li>
        </ul></div>
      </div>
      <div class="acc-g">
        <button class="acc-head" onclick="tg(this)">School &amp; learning<span class="tog">+</span></button>
        <div class="acc-body"><ul>
          <li>Handwriting is a real effort</li>
          <li>Struggles with reading and writing</li>
          <li>Has had a lot of therapy, but progress is slow</li>
          <li>Their EHCP isn't meeting their needs, or you're still fighting for one</li>
        </ul></div>
      </div>
    </div>
  </div>
</section>

<!-- 7. AREAS OF EXPERTISE -->
<section class="offer" id="offer">
  <div class="wrap">
    <h2 class="sec-h center-h">Different areas of expertise, depending on what your child needs.</h2>
    <p class="sec-sub center-h">Not five separate services to choose between. One assessment decides which of these your child's plan draws on.</p>
    <div class="offer-grid">
      <div class="oc"><h3>Speech, Language &amp; Communication</h3><p>Our core work for 25 years, including children who don't use words yet.</p></div>
      <div class="oc"><h3>Autism &amp; ADHD</h3><p>Communication, attention, regulation and sensory needs, with or without a diagnosis.</p></div>
      <div class="oc"><h3>Gut-Brain Testing</h3><p>Laboratory testing not available anywhere else in the UK. We recommend it, we never require it.</p></div>
      <div class="oc"><a href="/photobiomodulation-light-therapy-children/"><h3>The Lights On Method<span class="tm">&trade;</span></h3><p>Our light therapy programme, delivered in clinic as part of a wider plan.</p><span class="lnk">Read about it &rarr;</span></a></div>
      <div class="oc"><h3>EHCP &amp; SEND</h3><p>Expert reports for EHCPs and SEND tribunals, from one of the UK's most experienced expert witnesses.</p></div>
    </div>
  </div>
</section>

<!-- 8. BOOK / TRACKER -->
<section class="book" id="tracker">
  <div class="wrap book-grid">
    <div class="book-cover">
      <img src="https://articulatekids.co.uk/wp-content/uploads/2025/07/hulya-book-website-final.png" alt="Why Isn't My Child Talking? by Hulya Mehmet">
    </div>
    <div class="book-txt">
      <h2 class="sec-h">Get Hulya's 50-question Early Needs Tracker</h2>
      <p>Taken from <em>Why Isn't My Child Talking?</em> Spot early communication and sensory needs, track progress, and share clear information with your GP, nursery or school.</p>
      <form class="tk-form" onsubmit="return false">
        <input class="field" type="text" placeholder="First name" aria-label="First name">
        <input class="field" type="email" placeholder="Email address" aria-label="Email address">
        <button class="btn btn-p">Get the free tracker</button>
      </form>
    </div>
  </div>
</section>

<!-- 9a. CONDITIONS, GROUPED -->
<section class="cond" id="conditions">
  <div class="wrap">
    <h2 class="sec-h center-h">What we help with</h2>
    <div class="cond-cols">
      <div>
        <h3>Speech &amp; language</h3>
        <ul>
          <li><a href="/conditions-help/early-years-late-talkers/">Late talkers</a></li>
          <li><a href="/conditions-help/speech-sounds-development/">Speech delay</a></li>
          <li><a href="/conditions-help/language-development/">Language delay</a></li>
          <li><a href="/conditions-help/developmental-verbal-dyspraxia/">Verbal dyspraxia</a></li>
          <li><a href="/conditions-help/stuttering/">Stammering</a></li>
          <li><a href="/conditions-help/voice-disorders-dysphonia/">Voice disorders</a></li>
        </ul>
      </div>
      <div>
        <h3>Neurodevelopmental</h3>
        <ul>
          <li><a href="/conditions-help/autism/">Autism</a></li>
          <li><a href="/conditions-help/adhd/">ADHD</a></li>
          <li><a href="/conditions-help/behaviour/">Behaviour</a></li>
          <li><a href="/conditions-help/dyslexia-and-working-memory/">Dyslexia &amp; working memory</a></li>
        </ul>
      </div>
      <div>
        <h3>Eating &amp; school</h3>
        <ul>
          <li><a href="/conditions-help/dysphagia/">Dysphagia</a></li>
          <li><a href="/ehcp-tribunal-expert/">EHCP &amp; tribunals</a></li>
        </ul>
      </div>
    </div>
  </div>
</section>

<!-- 9b. HOW IT WORKS, SHORT -->
<section class="how">
  <div class="wrap">
    <h2 class="sec-h center-h">What happens when you get in touch</h2>
    <ol class="how-row">
      <li><b>Get in touch</b> Call, email or book online. No referral needed.</li>
      <li><b>First visit</b> A calm assessment at Orpington or Harley Street, or online.</li>
      <li><b>Your plan</b> A clear written report and a plan made for your child.</li>
    </ol>
  </div>
</section>

<!-- 9c. ARTICLES -->
<section class="arts">
  <div class="wrap">
    <h2 class="sec-h center-h">Expert guidance for parents</h2>
    <div class="arts-grid">
      <a class="art" href="/are-we-failing-girls-why-autism-often-goes-unrecognised-in-females/">
        <div class="thumb"><img src="https://articulatekids.co.uk/wp-content/uploads/2025/07/helena-lopes-CD5EJQbtDa8-unsplash-1024x683.jpg" alt=""></div>
        <h3>Are we failing girls? Why autism often goes unrecognised in females</h3>
      </a>
      <a class="art" href="/the-alarming-decline-in-childrens-motor-skills-why-movement-matters-more-than-ever/">
        <div class="thumb"><img src="https://articulatekids.co.uk/wp-content/uploads/2025/07/christian-bowen-C_0CMAE412s-unsplash-1024x678.jpg" alt=""></div>
        <h3>The alarming decline in children's motor skills, and why movement matters</h3>
      </a>
      <a class="art" href="/how-diet-affects-your-childs-speech-language-and-attention-a-speech-therapists-guide/">
        <div class="thumb"><img src="https://articulatekids.co.uk/wp-content/uploads/2026/01/young-kid-playing-with-fidget-home-1024x681.jpg" alt=""></div>
        <h3>How diet affects your child's speech, language and attention</h3>
      </a>
    </div>
    <div class="arts-all"><a class="lnk" href="/articles/">Read all articles &rarr;</a></div>
  </div>
</section>

<!-- 10. THREE ROUTES -->
<section class="routes">
  <div class="wrap">
    <h2 class="sec-h center-h">Wherever you are right now</h2>
    <div class="routes-grid">
      <div class="rt">
        <h3>Ready for help</h3>
        <a class="btn btn-p" href="/book-an-appointment/">Book an assessment</a>
      </div>
      <div class="rt">
        <h3>Want to understand more first</h3>
        <a class="btn btn-w" href="#webinar">Join the free monthly webinar</a>
      </div>
      <div class="rt">
        <h3>Want something useful now</h3>
        <a class="btn btn-w" href="#tracker">Get the free Early Needs Tracker</a>
      </div>
    </div>
  </div>
</section>

<!-- 11. FINAL CTA -->
<section class="final">
  <div class="wrap">
    <h2>Your child doesn't need to stay stuck.</h2>
    <a class="btn btn-p" href="/book-an-appointment/">Book an assessment</a>
    <p class="final-alt">Prefer to talk? Call <a href="tel:02038580765">020 3858 0765</a></p>
    <p class="final-alt">Not ready to book? <a href="#webinar">Join the free monthly webinar</a></p>
  </div>
</section>

<?php get_footer(); ?>

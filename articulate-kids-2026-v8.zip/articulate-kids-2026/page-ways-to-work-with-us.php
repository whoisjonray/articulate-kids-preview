<?php /* Template Name: Ways To Work With Us */ if(!defined("ABSPATH")) exit; get_header(); ?>
<style>
.w2w .wrap{max-width:1160px;margin-inline:auto;padding-left:clamp(24px,4vw,48px);padding-right:clamp(24px,4vw,48px)}
.w2w section{padding-top:clamp(46px,6vw,80px);padding-bottom:clamp(46px,6vw,80px)}
.w2w .sec-eye{display:inline-flex;align-items:center;gap:8px;font-family:'Baloo 2';font-weight:600;font-size:13.5px;color:var(--coral);background:var(--cream-2);padding:6px 15px;border-radius:100px;margin-bottom:14px}
.w2w .sec-h{font-family:'Baloo 2';font-size:clamp(26px,4vw,40px);font-weight:800;color:var(--indigo)}
.w2w .center{text-align:center;max-width:760px;margin-inline:auto}
.w2w .center .sec-h{margin-inline:auto}
.w2w .lead{font-size:17.5px;color:var(--ink-2);line-height:1.7;margin-top:14px}
.w2w .crumb{padding-top:26px;font-size:13.5px;color:var(--ink-3);font-weight:600}
.w2w .crumb a:hover{color:var(--coral)}.w2w .crumb span{color:var(--coral)}

/* price-pending chip: makes unconfirmed numbers obvious at a glance */
.w2w .tbc{display:inline-block;font-family:'Baloo 2';font-weight:700;font-size:19px;color:var(--gold);border:2px dashed var(--gold);border-radius:12px;padding:6px 14px;line-height:1.2}
.w2w .tbc small{display:block;font-family:'Nunito';font-weight:600;font-size:12px;color:var(--ink-3);letter-spacing:.02em}

.w2w .hero{position:relative;overflow:hidden;padding-top:clamp(30px,4vw,48px)}
.w2w .hero .blob{position:absolute;width:340px;height:340px;border-radius:50%;background:var(--apricot);top:-120px;right:-120px;z-index:0}
.w2w .hero-in{position:relative;z-index:1;max-width:760px}
.w2w .hero h1{font-family:'Baloo 2';font-size:clamp(36px,5.6vw,58px);font-weight:800;color:var(--indigo);margin-bottom:16px}
.w2w .hero .lede{font-size:clamp(17px,2vw,20px);color:var(--ink-2);max-width:56ch;line-height:1.62}

.w2w .packs{background:var(--cream-2)}
.w2w .pack-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;margin-top:40px;align-items:stretch}
.w2w .pk{background:#fff;border-radius:26px;padding:32px 28px 30px;box-shadow:0 14px 34px rgba(58,47,40,.07);position:relative;display:flex;flex-direction:column}
.w2w .pk.best{box-shadow:0 20px 46px rgba(59,54,132,.16);border:2px solid var(--indigo);padding-top:38px}
.w2w .pk-flag{position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:var(--indigo);color:#fff;font-family:'Baloo 2';font-weight:600;font-size:13px;padding:7px 20px;border-radius:100px;white-space:nowrap}
.w2w .pk-for{font-family:'Baloo 2';font-weight:600;font-size:13px;color:var(--coral);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px}
.w2w .pk h3{font-family:'Baloo 2';font-size:25px;color:var(--indigo);margin-bottom:10px;line-height:1.16}
.w2w .pk-blurb{font-size:15.5px;color:var(--ink-2);line-height:1.65;margin-bottom:20px}
.w2w .pk-price{font-family:'Baloo 2';font-weight:800;font-size:38px;color:var(--ink);line-height:1;margin-bottom:5px}
.w2w .pk-price small{font-family:'Nunito';font-weight:600;font-size:14.5px;color:var(--ink-3)}
.w2w .pk-sub{font-size:14px;color:var(--ink-3);font-weight:600;margin-top:8px;margin-bottom:22px}
.w2w .pk ul{list-style:none;margin-bottom:26px;padding:0}
.w2w .pk li{display:flex;gap:11px;align-items:flex-start;font-size:15.5px;color:var(--ink-2);line-height:1.55;margin-bottom:12px}
.w2w .pk li svg{flex-shrink:0;margin-top:2px;color:var(--coral);width:19px;height:19px;stroke:currentColor;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round}
.w2w .pk .btn{width:100%;justify-content:center;margin-top:auto}
@media(max-width:900px){.w2w .pack-grid{grid-template-columns:1fr;gap:26px}.w2w .pk.best{margin-top:14px}}

.w2w .between{background:var(--indigo);color:#fff}
.w2w .between .sec-h{color:#fff}
.w2w .between .lead{color:#CFCAEE}
.w2w .between .sec-eye{background:rgba(255,255,255,.14);color:#fff}
.w2w .bt-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:20px;margin-top:36px}
.w2w .bt{background:rgba(255,255,255,.09);border-radius:20px;padding:24px 22px}
.w2w .bt h3{font-family:'Baloo 2';font-size:17.5px;color:#fff;margin-bottom:7px}
.w2w .bt p{font-size:14.8px;color:#CFCAEE;line-height:1.6}

.w2w .ex-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;margin-top:34px}
.w2w .ex{background:#fff;border-radius:20px;padding:26px 24px;box-shadow:0 8px 22px rgba(58,47,40,.055)}
.w2w .ex h3{font-family:'Baloo 2';font-size:19px;color:var(--indigo);margin-bottom:8px}
.w2w .ex .p{font-family:'Baloo 2';font-weight:700;font-size:23px;color:var(--ink);margin-bottom:8px}
.w2w .ex p{font-size:15.2px;color:var(--ink-2);line-height:1.62}

.w2w .re{background:var(--cream-2)}
.w2w .re-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin-top:32px}
.w2w .rc{background:#fff;border-radius:20px;padding:26px 24px;box-shadow:0 8px 22px rgba(58,47,40,.05)}
.w2w .rc h3{font-family:'Baloo 2';font-size:18px;color:var(--indigo);margin-bottom:7px}
.w2w .rc p{font-size:15.2px;color:var(--ink-2);line-height:1.62}

.w2w .cta{text-align:center}
.w2w .cta .sec-h{margin-inline:auto;max-width:20ch}
.w2w .cta .lead{margin-inline:auto;max-width:56ch}
.w2w .cta-btns{display:flex;gap:13px;justify-content:center;flex-wrap:wrap;margin-top:26px}
</style>

<div class="w2w">

<div class="wrap">
  <div class="crumb"><a href="/">Home</a> &rsaquo; <span>Ways to work with us</span></div>
</div>

<section class="hero">
  <div class="wrap">
    <div class="blob"></div>
    <div class="hero-in">
      <span class="sec-eye">Ways to work with us</span>
      <h1>Pick the way that fits your family.</h1>
      <p class="lede">Most families start with an assessment. What comes next depends on your child. There's no wrong door, and you can change your mind as you go.</p>
    </div>
  </div>
</section>

<section class="packs">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">Three ways in</span>
      <h2 class="sec-h">Everything's included. No surprise invoices.</h2>
      <p class="lead">Reports, home programmes, emails between sessions and a call with your child's nursery or school are part of the price, not added on afterwards.</p>
    </div>

    <div class="pack-grid">

      <div class="pk">
        <div class="pk-for">Start here</div>
        <h3>Assessment</h3>
        <p class="pk-blurb">A thorough, unhurried look at how your child is getting on, and a clear written picture of what we found.</p>
        <span class="tbc">Price to confirm<small>Hulya to set</small></span>
        <div class="pk-sub">One-off</div>
        <ul>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A full assessment appointment</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A written report you can share with your GP, nursery or school</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A conversation with Hulya about what it all means</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>Honest advice on whether therapy is needed at all</span></li>
        </ul>
        <a class="btn btn-w" href="/book-an-appointment/">Book an assessment</a>
      </div>

      <div class="pk best">
        <span class="pk-flag">Our signature programme</span>
        <div class="pk-for">The full picture</div>
        <h3>Lights On<sup>&trade;</sup> Pathways Course</h3>
        <p class="pk-blurb">Twelve sessions of light therapy and speech therapy together, in the same appointment. Most families see the clearest change by sessions 10 to 12, which is why it's sold as a course rather than one session at a time.</p>
        <div class="pk-price">POA <small>&nbsp;quoted on a call</small></div>
        <div class="pk-sub">Twelve sessions, plus the plan behind them</div>
        <ul>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>Twelve Lights On sessions with Hulya, working on speech and motor tasks while the light is on</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A plan built for your child specifically, reviewed as you go</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A home programme, updated as your child moves</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A call with your child's nursery or school</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A written progress summary at the end of the course</span></li>
        </ul>
        <a class="btn btn-p" href="/photobiomodulation-light-therapy-children/">Read about Lights On first</a>
      </div>

      <div class="pk">
        <div class="pk-for">Therapy on its own</div>
        <h3>Speech and language block</h3>
        <p class="pk-blurb">Six weekly sessions with everything that happens between them. For children who don't need Lights On, or aren't ready for it yet.</p>
        <span class="tbc">Price to confirm<small>Hulya to set</small></span>
        <div class="pk-sub">Six sessions over about seven weeks</div>
        <ul>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>Six therapy sessions with Hulya</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A home programme, updated every week</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>Email support between sessions</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A call with your child's nursery or school</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A progress summary at the end, in writing</span></li>
        </ul>
        <a class="btn btn-w" href="/book-an-appointment/">Start a block</a>
      </div>

    </div>
  </div>
</section>

<section class="between">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">What you're actually paying for</span>
      <h2 class="sec-h">The hour in the room is about half of it.</h2>
      <p class="lead">Every course and block includes the work that happens when your child isn't here. Most of it is invisible to parents, and it's the part that makes therapy hold.</p>
    </div>
    <div class="bt-grid">
      <div class="bt">
        <h3>Building your child's plan</h3>
        <p>Every session is worked out from where your child got to last time, not pulled off a shelf.</p>
      </div>
      <div class="bt">
        <h3>Writing your home programme</h3>
        <p>Rewritten as you go, so what you're doing at home matches what we did in the room.</p>
      </div>
      <div class="bt">
        <h3>Talking to nursery and school</h3>
        <p>So the adults around your child are all pulling in the same direction.</p>
      </div>
      <div class="bt">
        <h3>Answering you in between</h3>
        <p>When something comes up on a Tuesday, you shouldn't have to sit on it until Friday.</p>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">Everything else</span>
      <h2 class="sec-h">If none of those are quite it.</h2>
    </div>
    <div class="ex-grid">
      <div class="ex">
        <h3>Whole Child Programme</h3>
        <div class="p">POA</div>
        <p>Assessment, brain and gut laboratory testing, and the Lights On course together, for families who want to understand what's driving the difficulty rather than only work on it.</p>
      </div>
      <div class="ex">
        <h3>Single session</h3>
        <div class="p"><span class="tbc" style="font-size:17px">Price to confirm<small>Hulya to set</small></span></div>
        <p>For families we already know, who want a one-off check-in or a top-up between courses.</p>
      </div>
      <div class="ex">
        <h3>EHCP and tribunal reports</h3>
        <div class="p">POA</div>
        <p>Expert reports for EHCPs and SEND tribunals, from one of the UK's most experienced expert witnesses.</p>
      </div>
    </div>
  </div>
</section>

<section class="re">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">Before you ask</span>
      <h2 class="sec-h">The things parents worry about.</h2>
    </div>
    <div class="re-grid">
      <div class="rc">
        <h3>Do I have to commit to a course?</h3>
        <p>No. If we assess your child and therapy isn't what they need, we'll tell you. Plenty of families come once and that's the end of it.</p>
      </div>
      <div class="rc">
        <h3>Why twelve Lights On sessions?</h3>
        <p>Because that's where the clearest change tends to show. One or two sessions won't tell you anything, and we'd rather be honest about that up front than sell you a session at a time.</p>
      </div>
      <div class="rc">
        <h3>Is Lights On instead of speech therapy?</h3>
        <p>Never. It's always alongside it, and it's never the first thing we reach for. In the course, the light goes on while your child is doing speech and motor work, so the appointment does both.</p>
      </div>
      <div class="rc">
        <h3>What if we need to stop?</h3>
        <p>Life happens. Talk to us and we'll work it out.</p>
      </div>
    </div>
  </div>
</section>

<section class="cta">
  <div class="wrap">
    <h2 class="sec-h">Not sure which one?</h2>
    <p class="lead">Come to Hulya's free live talk for parents. No booking, no pressure, and you'll leave with a much clearer idea of what your child actually needs.</p>
    <div class="cta-btns">
      <a class="btn btn-p" href="/#webinar">See the free webinar</a>
      <a class="btn btn-w" href="/book-an-appointment/">Talk to Hulya</a>
    </div>
  </div>
</section>

</div>
<?php get_footer(); ?>

<?php
if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', ['search-form','gallery','caption','style','script']);
    register_nav_menus(['primary' => 'Primary Menu', 'footer_where' => 'Footer: Where we help', 'footer_what' => 'Footer: What we do', 'footer_start' => 'Footer: Get started']);
});

add_action('wp_enqueue_scripts', function () {
    $dir = get_stylesheet_directory();
    $css_v = @filemtime($dir . '/assets/css/main.css') ?: wp_get_theme()->get('Version');
    $js_v  = @filemtime($dir . '/assets/js/main.js') ?: wp_get_theme()->get('Version');
    wp_enqueue_style('ak-fonts', 'https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Nunito:wght@400;500;600;700&display=swap', [], null);
    wp_enqueue_style('ak-main', get_stylesheet_directory_uri() . '/assets/css/main.css', [], $css_v);
    wp_enqueue_script('ak-main', get_stylesheet_directory_uri() . '/assets/js/main.js', [], $js_v, true);
});

// Preconnect for fonts
add_filter('wp_resource_hints', function ($hints, $relation) {
    if ('preconnect' === $relation) { $hints[] = 'https://fonts.gstatic.com'; }
    return $hints;
}, 10, 2);

// One-time programmatic creation of the Lights On service page (reliable; avoids SSH-gateway quoting issues)
add_action('init', function () {
    if (get_option('ak_lightson_page_created')) return;
    $slug = 'photobiomodulation-light-therapy-children';
    $existing = get_page_by_path($slug, OBJECT, 'page');
    if ($existing) { update_option('ak_lightson_page_created', 1); return; }
    $id = wp_insert_post([
        'post_type'   => 'page',
        'post_status' => 'publish',
        'post_title'  => 'Photobiomodulation and Light Therapy for Children',
        'post_name'   => $slug,
        'post_content'=> '',
    ]);
    if ($id && !is_wp_error($id)) {
        update_post_meta($id, '_wp_page_template', 'template-lights-on.php');
        update_option('ak_lightson_page_created', 1);
    }
});

// DoorGrow Claude editor (loaded from theme; WPEngine WAF blocks the Code Snippets REST POST)
$ak_editor = get_stylesheet_directory() . '/inc/dg-claude-editor.php';
if (file_exists($ak_editor)) require_once $ak_editor;

/**
 * Legacy /event/* URLs.
 *
 * The old coachpress theme registered a `cp-event` custom post type. Activating this
 * theme unregisters it, so four still-published posts (IDs 214, 215, 216, 1511) started
 * 404ing even though they return 200 on production. They have zero GSC impressions over
 * 90 days and are leftovers from a different business, so they get redirected to the
 * live /events/ page rather than resurrected. Without this they would 404 on go-live.
 */
add_action('template_redirect', function () {
    if (!is_404()) return;
    $path = strtok($_SERVER['REQUEST_URI'] ?? '', '?');
    if (preg_match('#^/event/[^/]+/?$#', $path)) {
        wp_safe_redirect(home_url('/events/'), 301);
        exit;
    }
});

/**
 * Legacy shortcode support.
 *
 * The old CoachPress/Divi stack provided [recent_posts], [et_pb_blurb],
 * [et_pb_testimonial] and friends. Under this theme they were printing as raw
 * text on live pages (/articles/, /conditions-help/, /testimonials/), and in the
 * case of [et_pb_blurb] they were hiding real internal links to every condition
 * page. Their attributes were also saved with smart quotes, so WordPress could
 * not parse them at all until those are normalised first.
 */

// Straighten smart quotes inside shortcode tags so the shortcode API can read them.
add_filter('the_content', function ($content) {
    if (strpos($content, '[') === false) return $content;
    return preg_replace_callback('/\[[^\]]+\]/', function ($m) {
        return str_replace(['&#8221;', '&#8220;', '&#8243;', '&#8242;', '”', '“', '″'], '"', $m[0]);
    }, $content);
}, 8);

add_shortcode('recent_posts', function ($atts) {
    $atts = shortcode_atts(['limit' => 12], $atts);
    $q = new WP_Query([
        'post_type'           => 'post',
        'posts_per_page'      => (int) $atts['limit'],
        'ignore_sticky_posts' => true,
    ]);
    if (!$q->have_posts()) return '';
    ob_start();
    echo '<div class="post-grid">';
    while ($q->have_posts()) {
        $q->the_post(); ?>
        <article class="post-card">
          <a class="post-card-media" href="<?php the_permalink(); ?>">
            <?php if (has_post_thumbnail()) { the_post_thumbnail('medium_large'); } else { ?>
              <span class="post-card-fallback" aria-hidden="true"></span>
            <?php } ?>
          </a>
          <div class="post-card-body">
            <div class="post-card-date"><?php echo esc_html(get_the_date('j F Y')); ?></div>
            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 20)); ?></p>
            <a class="post-card-more" href="<?php the_permalink(); ?>">Read the article &rarr;</a>
          </div>
        </article>
    <?php }
    echo '</div>';
    wp_reset_postdata();
    return ob_get_clean();
});

// Divi blurb: title + url + image. These carry the internal links on /conditions-help/.
add_shortcode('et_pb_blurb', function ($atts, $content = '') {
    $a = shortcode_atts(['title' => '', 'url' => '', 'image' => ''], $atts);
    if (!$a['title'] && !$content) return '';
    $inner = '<h3>' . esc_html($a['title']) . '</h3>';
    if ($content) $inner .= '<p>' . wp_kses_post(wp_strip_all_tags($content)) . '</p>';
    if ($a['url']) {
        return '<a class="lg-blurb" href="' . esc_url($a['url']) . '">' . $inner . '<span class="lg-arrow">&rarr;</span></a>';
    }
    return '<div class="lg-blurb">' . $inner . '</div>';
});

add_shortcode('et_pb_testimonial', function ($atts, $content = '') {
    $a = shortcode_atts(['author' => '', 'job_title' => ''], $atts);
    $body = trim(wp_kses_post($content));
    if (!$body) return '';
    $meta = trim($a['author'] . ($a['author'] && $a['job_title'] ? ' &middot; ' : '') . $a['job_title']);
    return '<figure class="lg-quote"><blockquote>' . $body . '</blockquote>'
         . ($meta ? '<figcaption>' . esc_html(wp_strip_all_tags($meta)) . '</figcaption>' : '')
         . '</figure>';
});

add_shortcode('et_pb_button', function ($atts, $content = '') {
    $a = shortcode_atts(['button_url' => '', 'button_text' => ''], $atts);
    $label = $a['button_text'] ?: wp_strip_all_tags($content);
    if (!$label) return '';
    if (!$a['button_url']) return '<span class="btn btn-w">' . esc_html($label) . '</span>';
    return '<a class="btn btn-p" href="' . esc_url($a['button_url']) . '">' . esc_html($label) . '</a>';
});

// Builder wrappers with nothing of their own to render: keep any inner content, drop the wrapper.
foreach (['et_pb_fullwidth_code', 'et_pb_section', 'et_pb_row', 'et_pb_column', 'et_pb_text'] as $ak_tag) {
    add_shortcode($ak_tag, function ($atts, $content = '') { return do_shortcode((string) $content); });
}
// Slider from a plugin that no longer exists.
add_shortcode('rev_slider', '__return_empty_string');

/**
 * Stop wpautop from breaking raw-HTML layout pages.
 *
 * The old Divi/CoachPress pages store fully-formed HTML (CSS grids, flin
 * containers). WordPress's auto-paragraph filter injects stray empty <p> tags
 * into that markup; inside a `grid-template-columns` container each empty <p>
 * becomes an empty grid cell, so cards render alternating with blank boxes
 * (seen on /services/). These pages already carry their own <p> tags, so
 * wpautop is pure damage here. Blog POSTS still need it (they store plain-text
 * paragraphs), so this only disables it for PAGES whose content is raw layout.
 */
add_action('wp', function () {
    if (!is_page()) return;
    $post = get_queried_object();
    if ($post instanceof WP_Post &&
        preg_match('/grid-template-columns|features-grid|services-grid|delivery-card|ak-hub-page|display:\s*flex/i', $post->post_content)) {
        remove_filter('the_content', 'wpautop');
        remove_filter('the_content', 'shortcode_unautop');
    }
});

/**
 * Wrap content tables so they scroll horizontally on mobile instead of
 * forcing the page wide (the EHCP comparison table did this). Applies to
 * post/page content only.
 */
add_filter('the_content', function ($content) {
    if (strpos($content, '<table') === false) return $content;
    return preg_replace('/(<table\b)/i', '<div class="table-scroll">$1', 
           preg_replace('/(<\/table>)/i', '$1</div>', $content));
}, 20);


// Reviews data + pull-quote helper
$ak_reviews_inc = get_stylesheet_directory() . "/inc/reviews.php";
if (file_exists($ak_reviews_inc)) require_once $ak_reviews_inc;

/**
 * Remove the fabricated aggregate star rating from RankMath's schema.
 *
 * RankMath's global Organization schema carried a hardcoded AggregateRating
 * (4.5 / 20 reviews) that appeared on EVERY page. It isn't a real aggregate,
 * it's misleading, and a self-serving/fake aggregate rating is a Google
 * rich-results violation. Strip aggregateRating from every schema entity.
 */
add_filter('rank_math/json_ld', function ($data, $jsonld) {
    $strip = function (&$node) use (&$strip) {
        if (!is_array($node)) return;
        unset($node['aggregateRating'], $node['ratingValue'], $node['reviewCount']);
        foreach ($node as &$child) { if (is_array($child)) $strip($child); }
    };
    $strip($data);
    return $data;
}, 99, 2);

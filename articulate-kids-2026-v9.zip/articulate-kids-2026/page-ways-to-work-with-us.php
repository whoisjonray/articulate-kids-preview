<?php /* Template Name: Ways To Work With Us */ if(!defined("ABSPATH")) exit; get_header(); ?>
<style>
.w2w .wrap{max-width:1160px;margin-inline:auto;padding-left:clamp(24px,4vw,48px);padding-right:clamp(24px,4vw,48px)}
.w2w section{padding-top:clamp(46px,6vw,80px);padding-bottom:clamp(46px,6vw,80px)}
.w2w .sec-eye{display:inline-flex;align-items:center;gap:8px;font-family:'Baloo 2';font-weight:600;font-size:13.5px;color:var(--coral);background:var(--cream-2);padding:6px 15px;border-radius:100px;margin-bottom:14px}
.w2w .sec-h{font-family:'Baloo 2';font-size:clamp(26px,4vw,40px);font-weight:800;color:var(--indigo)}
.w2w .center{text-align:center;max-width:760px;margin-inline:auto}
.w2w .center .sec-h{margin-inline:auto}
.w2w .lead{font-size:17.5px;color:var(--ink-2);line-height:1.7;margin-top:14px}
.w2w .crumb{padding-top:26px;font-size:13.5px;color:var(--ink-3);font-weight:600}
.w2w .crumb a:hover{color:var(--coral)}.w2w .crumb span{color:var(--coral)}

/* price-pending chip: makes unconfirmed numbers obvious at a glance */
.w2w .tbc{display:inline-block;font-family:'Baloo 2';font-weight:700;font-size:19px;color:var(--gold);border:2px dashed var(--gold);border-radius:12px;padding:6px 14px;line-height:1.2}
.w2w .tbc small{display:block;font-family:'Nunito';font-weight:600;font-size:12px;color:var(--ink-3);letter-spacing:.02em}

.w2w .hero{position:relative;overflow:hidden;padding-top:clamp(30px,4vw,48px)}
.w2w .hero .blob{position:absolute;width:340px;height:340px;border-radius:50%;background:var(--apricot);top:-120px;right:-120px;z-index:0}
.w2w .hero-in{position:relative;z-index:1;max-width:760px}
.w2w .hero h1{font-family:'Baloo 2';font-size:clamp(36px,5.6vw,58px);font-weight:800;color:var(--indigo);margin-bottom:16px}
.w2w .hero .lede{font-size:clamp(17px,2vw,20px);color:var(--ink-2);max-width:56ch;line-height:1.62}

.w2w .packs{background:var(--cream-2)}
.w2w .pack-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:22px;margin-top:40px;align-items:stretch}
.w2w .pk{background:#fff;border-radius:26px;padding:32px 28px 30px;box-shadow:0 14px 34px rgba(58,47,40,.07);position:relative;display:flex;flex-direction:column}
.w2w .pk.best{box-shadow:0 20px 46px rgba(59,54,132,.16);border:2px solid var(--indigo);padding-top:38px}
.w2w .pk-flag{position:absolute;top:-14px;left:50%;transform:translateX(-50%);background:var(--indigo);color:#fff;font-family:'Baloo 2';font-weight:600;font-size:13px;padding:7px 20px;border-radius:100px;white-space:nowrap}
.w2w .pk-for{font-family:'Baloo 2';font-weight:600;font-size:13px;color:var(--coral);text-transform:uppercase;letter-spacing:.05em;margin-bottom:8px}
.w2w .pk h3{font-family:'Baloo 2';font-size:25px;color:var(--indigo);margin-bottom:10px;line-height:1.16}
.w2w .pk-blurb{font-size:15.5px;color:var(--ink-2);line-height:1.65;margin-bottom:20px}
.w2w .pk-price{font-family:'Baloo 2';font-weight:800;font-size:38px;color:var(--ink);line-height:1;margin-bottom:5px}
.w2w .pk-price small{font-family:'Nunito';font-weight:600;font-size:14.5px;color:var(--ink-3)}
.w2w .pk-sub{font-size:14px;color:var(--ink-3);font-weight:600;margin-top:8px;margin-bottom:22px}
.w2w .pk ul{list-style:none;margin-bottom:26px;padding:0}
.w2w .pk li{display:flex;gap:11px;align-items:flex-start;font-size:15.5px;color:var(--ink-2);line-height:1.55;margin-bottom:12px}
.w2w .pk li svg{flex-shrink:0;margin-top:2px;color:var(--coral);width:19px;height:19px;stroke:currentColor;stroke-width:2.2;fill:none;stroke-linecap:round;stroke-linejoin:round}
.w2w .pk .btn{width:100%;justify-content:center;margin-top:auto}
@media(max-width:900px){.w2w .pack-grid{grid-template-columns:1fr;gap:26px}.w2w .pk.best{margin-top:14px}}

.w2w .between{background:var(--indigo);color:#fff}
.w2w .between .sec-h{color:#fff}
.w2w .between .lead{color:#CFCAEE}
.w2w .between .sec-eye{background:rgba(255,255,255,.14);color:#fff}
.w2w .bt-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:20px;margin-top:36px}
.w2w .bt{background:rgba(255,255,255,.09);border-radius:20px;padding:24px 22px}
.w2w .bt h3{font-family:'Baloo 2';font-size:17.5px;color:#fff;margin-bottom:7px}
.w2w .bt p{font-size:14.8px;color:#CFCAEE;line-height:1.6}

.w2w .ex-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:20px;margin-top:34px}
.w2w .ex{background:#fff;border-radius:20px;padding:26px 24px;box-shadow:0 8px 22px rgba(58,47,40,.055)}
.w2w .ex h3{font-family:'Baloo 2';font-size:19px;color:var(--indigo);margin-bottom:8px}
.w2w .ex .p{font-family:'Baloo 2';font-weight:700;font-size:23px;color:var(--ink);margin-bottom:8px}
.w2w .ex p{font-size:15.2px;color:var(--ink-2);line-height:1.62}

.w2w .re{background:var(--cream-2)}
.w2w .re-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:20px;margin-top:32px}
.w2w .rc{background:#fff;border-radius:20px;padding:26px 24px;box-shadow:0 8px 22px rgba(58,47,40,.05)}
.w2w .rc h3{font-family:'Baloo 2';font-size:18px;color:var(--indigo);margin-bottom:7px}
.w2w .rc p{font-size:15.2px;color:var(--ink-2);line-height:1.62}

.w2w .cta{text-align:center}
.w2w .cta .sec-h{margin-inline:auto;max-width:20ch}
.w2w .cta .lead{margin-inline:auto;max-width:56ch}
.w2w .cta-btns{display:flex;gap:13px;justify-content:center;flex-wrap:wrap;margin-top:26px}
</style>

<div class="w2w">

<div class="wrap">
  <div class="crumb"><a href="/">Home</a> &rsaquo; <span>Ways to work with us</span></div>
</div>

<section class="hero">
  <div class="wrap">
    <div class="blob"></div>
    <div class="hero-in">
      <span class="sec-eye">Ways to work with us</span>
      <h1>Pick the way that fits your family.</h1>
      <p class="lede">Most families start with an assessment. What comes next depends on your child. There's no wrong door, and you can change your mind as you go.</p>
    </div>
  </div>
</section>

<section class="packs">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">Three ways in</span>
      <h2 class="sec-h">Everything's included. No surprise invoices.</h2>
      <p class="lead">Reports, home programmes, emails between sessions and a call with your child's nursery or school are part of the price, not added on afterwards.</p>
    </div>

    <div class="pack-grid">

      <div class="pk">
        <div class="pk-for">Start here</div>
        <h3>Assessment</h3>
        <p class="pk-blurb">A thorough, unhurried look at how your child is getting on, and a clear written picture of what we found.</p>
        <div class="pk-price">£347</div>
        <div class="pk-sub">Pre-school age &middot; £367 primary age</div>
        <ul>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A full assessment appointment</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A written report you can share with your GP, nursery or school</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A conversation with Hulya about what it all means</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>Honest advice on whether therapy is needed at all</span></li>
        </ul>
        <a class="btn btn-w" href="/book-an-appointment/">Book an assessment</a>
      </div>

      <div class="pk best">
        <span class="pk-flag">Our signature programme</span>
        <div class="pk-for">The full picture</div>
        <h3>Lights On<sup>&trade;</sup> Pathways Course</h3>
        <p class="pk-blurb">Ten laser sessions, each one working your child's brain, body and speech while the light is on. Most families notice change early, often by around session five.</p>
        <div class="pk-price">£3,300 <small>&nbsp;£330 a session</small></div>
        <div class="pk-sub">A block of ten. We don't sell them singly.</div>
        <ul>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>Ten Lights On sessions with Hulya</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>Targeted brain, body and motor tasks in every session, chosen to support your child's speech targets</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A plan built for your child specifically, reviewed as you go</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A call with your child's nursery or school</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>Stop whenever you like and we refund the sessions you haven't used</span></li>
        </ul>
        <a class="btn btn-p" href="/photobiomodulation-light-therapy-children/">Read about Lights On first</a>
      </div>

      <div class="pk">
        <div class="pk-for">Therapy on its own</div>
        <h3>Speech and language therapy</h3>
        <p class="pk-blurb">Our core work, and what we've done for 25 years. Book it on its own, or alongside a Lights On course. Most families doing Lights On book these separately.</p>
        <div class="pk-price">£95 <small>&nbsp;a session</small></div>
        <div class="pk-sub">Book as many or as few as you need</div>
        <ul>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>One-to-one therapy with Hulya</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>Built around your child, including children who don't use words yet</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>A home programme so the work carries on between visits</span></li>
          <li><svg viewBox="0 0 24 24"><path d="M20 6L9 17l-5-5"/></svg><span>No block to commit to and no minimum</span></li>
        </ul>
        <a class="btn btn-w" href="/book-an-appointment/">Book a session</a>
      </div>

    </div>
  </div>
</section>

<section class="between">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">What you're actually paying for</span>
      <h2 class="sec-h">The hour in the room is about half of it.</h2>
      <p class="lead">A Lights On course includes the work that happens when your child isn't here. Most of it is invisible to parents, and it's the part that makes any of it hold.</p>
    </div>
    <div class="bt-grid">
      <div class="bt">
        <h3>Building your child's plan</h3>
        <p>Every session is worked out from where your child got to last time, not pulled off a shelf.</p>
      </div>
      <div class="bt">
        <h3>Writing your home programme</h3>
        <p>Rewritten as you go, so what you're doing at home matches what we did in the room.</p>
      </div>
      <div class="bt">
        <h3>Talking to nursery and school</h3>
        <p>So the adults around your child are all pulling in the same direction.</p>
      </div>
      <div class="bt">
        <h3>Answering you in between</h3>
        <p>When something comes up on a Tuesday, you shouldn't have to sit on it until Friday.</p>
      </div>
    </div>
  </div>
</section>

<section>
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">Everything else</span>
      <h2 class="sec-h">If none of those are quite it.</h2>
    </div>
    <div class="ex-grid">
      <div class="ex">
        <h3>Lights On top-up block</h3>
        <div class="p">£1,650</div>
        <p>Five more sessions, for families who've finished the first ten and want to keep going. Only available once you've done the initial block.</p>
      </div>
      <div class="ex">
        <h3>Brain, gut and food testing</h3>
        <div class="p">£1,500</div>
        <p>Three laboratory panels, usually gut, neural and food. The price covers the tests themselves, Hulya reviewing the results with the laboratory, a meeting to talk you through what they mean, and a written plan to follow.</p>
      </div>
      <div class="ex">
        <h3>EHCP and tribunal reports</h3>
        <div class="p">POA</div>
        <p>Expert reports for EHCPs and SEND tribunals, from one of the UK's most experienced expert witnesses.</p>
      </div>
    </div>
  </div>
</section>

<section class="re">
  <div class="wrap">
    <div class="center">
      <span class="sec-eye">Before you ask</span>
      <h2 class="sec-h">The things parents worry about.</h2>
    </div>
    <div class="re-grid">
      <div class="rc">
        <h3>What if we start and it isn't working?</h3>
        <p>Stop, and we'll refund every session you haven't used. You're never locked into the rest of the block, which is exactly why we're comfortable selling it as one.</p>
      </div>
      <div class="rc">
        <h3>Why a block of ten?</h3>
        <p>Because one or two sessions won't tell you anything. Most families notice change earlier than that, often by around session five, but ten is the honest length of a first course.</p>
      </div>
      <div class="rc">
        <h3>Is Lights On instead of speech therapy?</h3>
        <p>Never. A Lights On session isn't a full speech therapy session. Hulya works on tasks that support your child's speech targets while the light is on, and most families book their speech therapy sessions separately alongside it.</p>
      </div>
      <div class="rc">
        <h3>Do I have to commit to anything?</h3>
        <p>No. Speech therapy is booked a session at a time with no minimum, and if we assess your child and therapy isn't what they need, we'll tell you.</p>
      </div>
      <div class="rc">
        <h3>Can I pay in instalments?</h3>
        <p>Courses are paid in full when you book.</p>
      </div>
      <div class="rc">
        <h3>What if I need to move an appointment?</h3>
        <p>Just let us know at least 48 hours ahead and it's no problem. Inside 48 hours there's a £50 late notice fee.</p>
      </div>
    </div>
  </div>
</section>

<section class="cta">
  <div class="wrap">
    <h2 class="sec-h">Not sure which one?</h2>
    <p class="lead">Book a free 10 minute call with Hulya. Long enough to work out what your child actually needs, short enough that nobody has to sit through a sales pitch. Or come to the free live talk for parents first.</p>
    <div class="cta-btns">
      <a class="btn btn-p" href="/book-an-appointment/">Book a free 10 minute call</a>
      <a class="btn btn-w" href="/#webinar">See the free webinar</a>
    </div>
  </div>
</section>

</div>
<?php get_footer(); ?>

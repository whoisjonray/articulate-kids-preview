<?php
/**
 * Gut-Brain Testing service page.
 *
 * Targets the winnable UK terms "gut brain axis" (2,400/mo, low comp),
 * "gut brain connection" (720) and "gut health test" (1,900). Every clinical
 * statement here is either educational (how the gut-brain axis works) or lifted
 * verbatim in spirit from Hulya's already-approved Lights On page framing:
 * testing is "not used to diagnose anything", it's "one extra source of
 * information", never used alone. No efficacy claims are invented — anything
 * she needs to confirm is flagged in the pending doc, not asserted here.
 *
 * Scoped under `.gbt` and uses the global stylesheet (main.css) for base/nav/
 * footer — it does NOT re-declare them, which is what knocked the old Lights On
 * template off-centre.
 */
if (!defined('ABSPATH')) exit;
get_header(); ?>

<div class="gbt">
  <div class="wrap crumb-wrap">
    <div class="crumb"><a href="/">Home</a> &rsaquo; <a href="/#offer">What we offer</a> &rsaquo; <span>Gut-brain testing</span></div>
  </div>

  <header class="gbt-hero">
    <div class="wrap">
      <span class="sec-eye">Whole-child assessment</span>
      <h1>Gut-brain testing for children</h1>
      <p class="gbt-lede">The gut and the brain are in constant conversation. When a child is struggling with communication, attention, mood, sleep or eating, looking at the gut-brain connection can add a piece of the picture that speech therapy alone can't see. We use specialist laboratory testing to help build that fuller picture.</p>
      <div class="gbt-cta">
        <a class="btn btn-p" href="/book-an-appointment/">Book an appointment</a>
        <a class="btn btn-w" href="#webinar">Ask us at the free webinar</a>
      </div>
      <p class="gbt-note">We recommend testing where it's relevant. We never require it.</p>
    </div>
  </header>

  <section class="gbt-body">
    <div class="wrap narrow">

      <h2>What is the gut-brain axis?</h2>
      <p>The gut-brain axis is the two-way communication network between the digestive system and the brain. It's a genuinely active area of scientific research, and it's why a problem that shows up as behaviour, focus or communication sometimes has roots that aren't in the brain alone. The nervous system carries signals between the brain, the body and the gut, rather than sitting in one isolated place.</p>
      <p>For some children, what's happening in the gut, in the immune system, or in how they process certain foods is one of the things worth understanding when the usual approaches haven't given the full answer.</p>

      <h2>What we look at</h2>
      <p>When it's relevant for a child, Hulya may draw on functional laboratory testing from one of the world's leading specialist labs. It usually involves three panels:</p>
      <ul class="gbt-list">
        <li><b>Gut.</b> A detailed look at the gut microbiome, digestion, the gut lining, and the balance of microbes that influence inflammation and the gut-brain signals.</li>
        <li><b>Neural.</b> Markers related to the brain and nervous system, to help understand whether anything in this area may be part of the picture.</li>
        <li><b>Food.</b> How your child's body is responding to specific foods, which can be relevant for children with restricted eating, gut symptoms or sensory-related feeding patterns.</li>
      </ul>

      <div class="gbt-callout">
        <b>An honest word on what this is, and isn't.</b> Testing here isn't used to diagnose anything, and it's never used on its own or as a first port of call. It's one extra source of information, sitting alongside clinical observation, your child's speech and language therapy, and, where appropriate, your GP. It informs the plan. It doesn't replace it.
      </div>

      <h2>How it fits the whole-child plan</h2>
      <p>Articulate Kids is the only clinic in the UK bringing speech and language therapy together with brain and gut laboratory testing and the Lights On&trade; Method, and we're the exclusive UK provider of this testing. That matters because the results don't sit in a folder. Hulya reviews them with the laboratory, meets with you to talk through what they mean in plain English, and turns them into a written plan you can actually follow.</p>
      <p>After more than 25 years and 40,000 appointments, what she brings to the results isn't just a set of numbers. It's the experience to see how a child's gut, brain, senses and communication fit together, and to know which threads are worth pulling.</p>

      <h2>Who it's for</h2>
      <p>Testing tends to be most useful for families who want to understand what might be driving a difficulty, not just work on the symptoms, and for children where communication concerns sit alongside things like restricted eating, gut symptoms, sleep problems, or big swings in mood and regulation. If you're not sure whether it's right for your child, that's exactly what the assessment and a conversation with Hulya are for.</p>

      <div class="gbt-price">
        <div class="gbt-price-fig">&pound;1,500</div>
        <div>
          <b>Brain, gut and food testing</b>
          <p>Three panels, usually gut, neural and food. The price covers the tests, Hulya reviewing the results with the laboratory, a meeting to talk you through what they mean, and a written plan to follow.</p>
        </div>
      </div>
    </div>
  </section>

  <section class="gbt-faq" id="faq">
    <div class="wrap narrow">
      <h2 class="center-h">Common questions</h2>
      <div class="faq-wrap">
        <details class="fi"><summary class="fq">Do we have to do the testing?<span class="t" aria-hidden="true">+</span></summary><div class="fa"><p>No. Nothing beyond an assessment is required to work with us. We recommend testing where it's genuinely relevant, and we're always happy to explain why. It's your decision.</p></div></details>
        <details class="fi"><summary class="fq">Is it suitable for children?<span class="t" aria-hidden="true">+</span></summary><div class="fa"><p>Yes. The samples are collected gently, and for the gut panel that's usually done at home rather than in clinic.</p></div></details>
        <details class="fi"><summary class="fq">Will the test diagnose my child?<span class="t" aria-hidden="true">+</span></summary><div class="fa"><p>No. It isn't a diagnostic tool. It's one extra source of information that feeds into a wider plan, alongside clinical assessment and, where appropriate, your GP.</p></div></details>
        <details class="fi"><summary class="fq">What happens after the results come back?<span class="t" aria-hidden="true">+</span></summary><div class="fa"><p>Hulya reviews them with the laboratory, then meets with you to explain what they mean in plain English and writes you a clear plan to follow. You're never left to interpret a report on your own.</p></div></details>
      </div>
    </div>
  </section>

  <section class="gbt-final">
    <div class="wrap">
      <h2>Want to understand what's really going on?</h2>
      <p>Start with an assessment, or come to Hulya's free monthly webinar where she explains the whole-child approach and answers parents' questions.</p>
      <div class="gbt-cta center">
        <a class="btn btn-p" href="/book-an-appointment/">Book an assessment</a>
        <a class="btn btn-w" href="/#webinar">See the free webinar</a>
      </div>
    </div>
  </section>
</div>

<?php get_footer(); ?>

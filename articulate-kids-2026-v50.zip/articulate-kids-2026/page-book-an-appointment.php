<?php
/**
 * Booking page.
 *
 * The content is a SimplyBook.it iframe widget wrapped in the legacy
 * `.page-content` markup. Under the generic renderer it inherited a narrow
 * column and the injected iframe sat squeezed on the right with the left half
 * of the page empty. This template drops it into a full-width centred container
 * and forces the injected iframe to fill it and stay responsive on mobile.
 */
if (!defined('ABSPATH')) exit;
get_header(); ?>

<div class="book-page">
  <div class="wrap">
    <div class="book-head">
      <h1>Book an Appointment</h1>
      <p>Choose a service and a time below. The secure booking form takes a few seconds to load.</p>
      <p class="book-phone">Prefer to talk it through first? Call <a href="tel:02038580765">020 3858 0765</a>.</p>
    </div>

    <?php while (have_posts()) : the_post();
        // render only the widget markup, not the legacy <h1>/<p> the content also carries
        $ak_c = get_the_content();
        if (preg_match('/<div class="booking-widget">.*/s', $ak_c, $mm)) {
            echo '<div class="book-widget-wrap">' . do_shortcode($mm[0]) . '</div>';
        } else {
            echo '<div class="prose">' . apply_filters('the_content', $ak_c) . '</div>';
        }
    endwhile; ?>
  </div>
</div>

<?php get_footer(); ?>

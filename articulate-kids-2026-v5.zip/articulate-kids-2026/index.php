<?php if (!defined('ABSPATH')) exit; get_header(); ?>
<main class="wrap" style="padding-block:clamp(40px,6vw,80px);max-width:820px">
<?php while (have_posts()) : the_post(); ?>
  <article>
    <h1 class="sec-h" style="margin-bottom:20px"><?php the_title(); ?></h1>
    <div class="prose entry-content"><?php the_content(); ?></div>
  </article>
<?php endwhile; ?>
</main>
<?php get_footer();

<?php
if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', ['search-form','gallery','caption','style','script']);
    register_nav_menus(['primary' => 'Primary Menu', 'footer_where' => 'Footer: Where we help', 'footer_what' => 'Footer: What we do', 'footer_start' => 'Footer: Get started']);
});

add_action('wp_enqueue_scripts', function () {
    $dir = get_stylesheet_directory();
    $css_v = @filemtime($dir . '/assets/css/main.css') ?: wp_get_theme()->get('Version');
    $js_v  = @filemtime($dir . '/assets/js/main.js') ?: wp_get_theme()->get('Version');
    wp_enqueue_style('ak-fonts', 'https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Nunito:wght@400;500;600;700&display=swap', [], null);
    wp_enqueue_style('ak-main', get_stylesheet_directory_uri() . '/assets/css/main.css', [], $css_v);
    wp_enqueue_script('ak-main', get_stylesheet_directory_uri() . '/assets/js/main.js', [], $js_v, true);
});

// Preconnect for fonts
add_filter('wp_resource_hints', function ($hints, $relation) {
    if ('preconnect' === $relation) { $hints[] = 'https://fonts.gstatic.com'; }
    return $hints;
}, 10, 2);

// One-time programmatic creation of the Lights On service page (reliable; avoids SSH-gateway quoting issues)
add_action('init', function () {
    if (get_option('ak_lightson_page_created')) return;
    $slug = 'photobiomodulation-light-therapy-children';
    $existing = get_page_by_path($slug, OBJECT, 'page');
    if ($existing) { update_option('ak_lightson_page_created', 1); return; }
    $id = wp_insert_post([
        'post_type'   => 'page',
        'post_status' => 'publish',
        'post_title'  => 'Photobiomodulation and Light Therapy for Children',
        'post_name'   => $slug,
        'post_content'=> '',
    ]);
    if ($id && !is_wp_error($id)) {
        update_post_meta($id, '_wp_page_template', 'template-lights-on.php');
        update_option('ak_lightson_page_created', 1);
    }
});

// DoorGrow Claude editor (loaded from theme; WPEngine WAF blocks the Code Snippets REST POST)
$ak_editor = get_stylesheet_directory() . '/inc/dg-claude-editor.php';
if (file_exists($ak_editor)) require_once $ak_editor;

/**
 * Legacy /event/* URLs.
 *
 * The old coachpress theme registered a `cp-event` custom post type. Activating this
 * theme unregisters it, so four still-published posts (IDs 214, 215, 216, 1511) started
 * 404ing even though they return 200 on production. They have zero GSC impressions over
 * 90 days and are leftovers from a different business, so they get redirected to the
 * live /events/ page rather than resurrected. Without this they would 404 on go-live.
 */
add_action('template_redirect', function () {
    if (!is_404()) return;
    $path = strtok($_SERVER['REQUEST_URI'] ?? '', '?');
    if (preg_match('#^/event/[^/]+/?$#', $path)) {
        wp_safe_redirect(home_url('/events/'), 301);
        exit;
    }
});

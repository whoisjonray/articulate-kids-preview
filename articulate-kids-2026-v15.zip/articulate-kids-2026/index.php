<?php
/**
 * Archive / blog listing.
 *
 * The previous version looped posts and printed every title as an <h1>, so the
 * blog index shipped ten H1s. The page now carries one H1 and each card title
 * is an H2.
 */
if (!defined('ABSPATH')) exit;
get_header(); ?>

<div class="wrap entry-wrap">

  <div class="entry-head">
    <h1><?php
      if (is_home() && !is_front_page()) {
          $ak_posts_page = get_option('page_for_posts');
          echo esc_html($ak_posts_page ? get_the_title($ak_posts_page) : 'Articles for parents');
      } elseif (is_search()) {
          echo 'Search results for &ldquo;' . esc_html(get_search_query()) . '&rdquo;';
      } elseif (is_archive()) {
          echo esc_html(wp_strip_all_tags(get_the_archive_title()));
      } else {
          echo 'Articles for parents';
      }
    ?></h1>
    <p class="entry-meta">Practical guidance on children's communication, from Hulya Mehmet</p>
  </div>

  <?php if (have_posts()) : ?>
    <div class="post-grid">
      <?php while (have_posts()) : the_post(); ?>
        <article class="post-card">
          <a class="post-card-media" href="<?php the_permalink(); ?>">
            <?php if (has_post_thumbnail()) {
                the_post_thumbnail('medium_large');
            } else { ?>
              <span class="post-card-fallback" aria-hidden="true"></span>
            <?php } ?>
          </a>
          <div class="post-card-body">
            <div class="post-card-date"><?php echo esc_html(get_the_date('j F Y')); ?></div>
            <h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
            <p><?php echo esc_html(wp_trim_words(get_the_excerpt(), 22)); ?></p>
            <a class="post-card-more" href="<?php the_permalink(); ?>">Read the article &rarr;</a>
          </div>
        </article>
      <?php endwhile; ?>
    </div>

    <div class="post-pager"><?php
      the_posts_pagination([
        'mid_size'  => 1,
        'prev_text' => '&larr; Newer',
        'next_text' => 'Older &rarr;',
      ]);
    ?></div>

  <?php else : ?>
    <p class="prose">Nothing here yet. Try the <a href="/">homepage</a>.</p>
  <?php endif; ?>

</div>

<?php get_footer();

<?php
/**
 * Single post (blog article).
 *
 * The 38 migrated posts are the site's biggest organic traffic source, so this
 * only wraps and styles them. It never alters the content or its headings.
 */
if (!defined('ABSPATH')) exit;
get_header(); ?>

<?php while (have_posts()) : the_post(); ?>
<?php
    $ak_content    = apply_filters('the_content', get_the_content());
    $ak_has_own_h1 = (bool) preg_match('/<h1[\s>]/i', $ak_content);
?>
  <article class="wrap entry-wrap">

    <div class="entry-head">
      <?php if (!$ak_has_own_h1) : ?>
        <h1><?php the_title(); ?></h1>
      <?php endif; ?>
      <div class="entry-meta"><?php echo esc_html(get_the_date('j F Y')); ?> &middot; Hulya Mehmet</div>
    </div>

    <?php if (has_post_thumbnail()) : ?>
      <div class="prose" style="margin-bottom:30px"><?php the_post_thumbnail('large'); ?></div>
    <?php endif; ?>

    <div class="prose entry-content"><?php echo $ak_content; ?></div>

    <aside class="entry-cta">
      <h2>Worried about your child's talking?</h2>
      <p>Book a free 10 minute call with Hulya, or come to the free live talk for parents. No pressure either way.</p>
      <a class="btn btn-p" href="/book-an-appointment/">Book a free 10 minute call</a>
    </aside>

  </article>
<?php endwhile; ?>

<?php get_footer();

<?php /* Template Name: Lights On Service Page */ if(!defined("ABSPATH")) exit; get_header(); ?>
<style>
/* Page-specific rules only. This template used to re-declare the whole base
   stylesheet (:root, body, .wrap, nav, .btn, footer). Because it loads after
   main.css it silently overrode the real nav and wrapper, which knocked the
   page off centre and reverted the header. Globals now come from main.css. */


.crumb{padding-top:26px;font-size:13.5px;color:var(--ink-3);font-weight:600}
.crumb a:hover{color:var(--coral)}.crumb span{color:var(--coral)}

.hero{position:relative;overflow:hidden;padding-block:24px clamp(40px,5vw,64px)}
.hero .blob{position:absolute;width:320px;height:320px;border-radius:50%;background:var(--apricot);top:-90px;right:-110px;z-index:0}
.hero-in{position:relative;z-index:1}
.eyebrow{display:inline-flex;align-items:center;gap:8px;font-family:'Baloo 2';font-weight:600;font-size:13.5px;color:var(--coral);background:var(--cream-2);padding:6px 16px;border-radius:100px;margin-bottom:16px}
.hero h1{font-family:'Baloo 2';font-size:clamp(30px,4.6vw,50px);font-weight:800;color:var(--indigo);margin:0 auto 14px;max-width:20ch}
.hero .lede{font-size:clamp(16.5px,1.9vw,19px);color:var(--ink-2);max-width:60ch;margin:0 auto 24px;line-height:1.65}
.hero .lede b{color:var(--ink)}
.hero-cta{display:flex;gap:13px;flex-wrap:wrap;justify-content:center;margin-bottom:22px}
.hero-pills{display:flex;gap:10px;flex-wrap:wrap;justify-content:center}
.hp{font-family:'Baloo 2';font-size:12.5px;font-weight:600;color:var(--indigo);background:#fff;box-shadow:0 4px 12px rgba(58,47,40,.06);padding:7px 15px;border-radius:100px}

.article{padding-block:clamp(36px,5vw,56px);text-align:left}
.art-body{max-width:760px;margin-inline:auto}
.art-body h2{font-family:'Baloo 2';font-size:clamp(23px,3vw,32px);font-weight:800;color:var(--indigo);margin:40px 0 6px}
.art-body h2:first-child{margin-top:0}
.art-body p{font-size:17px;color:var(--ink-2);line-height:1.8;margin-top:16px}
.art-body p b{color:var(--ink)}
.art-body ul{margin:16px 0 0;padding-left:0;list-style:none;display:flex;flex-direction:column;gap:10px}
.art-body ul li{position:relative;padding-left:30px;font-size:16.5px;color:var(--ink-2);line-height:1.6}
.art-body ul li::before{content:"";position:absolute;left:6px;top:9px;width:9px;height:9px;border-radius:50%;background:var(--coral)}
.callout{background:var(--sky);border-radius:18px;padding:22px 26px;margin-top:22px;font-size:16px;color:var(--ink-2);line-height:1.7}
.callout b{color:var(--indigo)}

/* author E-E-A-T card */
.author{background:var(--indigo);color:#fff;border-radius:24px;padding:clamp(26px,4vw,40px);margin-top:36px;display:grid;grid-template-columns:150px 1fr;gap:28px;align-items:center;overflow:hidden;position:relative}
.author .ph{width:150px;height:180px;border-radius:18px;overflow:hidden;background:linear-gradient(155deg,#E7D2F0,#D3BAE6)}
.author .ph img{width:100%;height:100%;object-fit:cover;object-position:center top}
.author h3{font-family:'Baloo 2';font-size:22px;color:#fff;margin-bottom:4px}
.author .role{font-family:'Baloo 2';font-weight:600;font-size:13.5px;color:var(--amber);margin-bottom:12px}
.author p{font-size:15px;color:rgba(255,255,255,.82);line-height:1.7}
.author p b{color:#fff}
@media(max-width:620px){.author{grid-template-columns:1fr;text-align:center}.author .ph{width:140px;height:170px;margin-inline:auto}}

.disclaimer{margin-top:30px;font-size:13.5px;color:var(--ink-3);font-style:italic;line-height:1.6;border-top:1px solid var(--line);padding-top:20px}

/* FAQ */
.faq{background:var(--sky)}
.faq-wrap{max-width:820px;margin:28px auto 0;display:flex;flex-direction:column;gap:12px}
.fi{background:#fff;border-radius:18px;box-shadow:0 6px 18px rgba(58,47,40,.05);overflow:hidden}
.fq{width:100%;background:none;border:none;text-align:left;font-family:'Baloo 2';font-size:17px;font-weight:600;color:var(--indigo);padding:18px 22px;display:flex;justify-content:space-between;gap:16px;cursor:pointer;align-items:center}
.fq .t{width:28px;height:28px;border-radius:50%;background:var(--cream-2);color:var(--coral);display:grid;place-items:center;font-size:19px;flex-shrink:0;transition:.25s;font-family:'Nunito'}
.fi.open .fq .t{background:var(--coral);color:#fff;transform:rotate(45deg)}
.fa{font-size:15.5px;color:var(--ink-2);line-height:1.7;padding:0 22px 18px;display:none}.fi.open .fa{display:block}

/* webinar + cta bands */
.webinar{background:var(--cream-2)}
.web-card{background:#fff;border-radius:24px;padding:clamp(28px,4vw,40px);max-width:900px;margin-inline:auto;display:grid;grid-template-columns:1.1fr .9fr;gap:36px;align-items:center;box-shadow:0 16px 40px rgba(58,47,40,.08)}
.web-card .free{display:inline-block;font-family:'Baloo 2';font-size:12px;font-weight:700;color:#fff;background:var(--coral);padding:4px 12px;border-radius:100px;margin-bottom:12px}
.web-card h2{font-family:'Baloo 2';font-size:26px;color:var(--indigo);margin-bottom:8px}
.web-card p{font-size:15.5px;color:var(--ink-2);line-height:1.65}
.web-when{margin-top:12px;font-family:'Baloo 2';font-weight:600;font-size:14px;color:var(--coral)}
.web-form .field{width:100%;padding:13px 16px;border:1px solid var(--line);border-radius:100px;font-family:'Nunito';font-size:15px;margin-bottom:10px;background:var(--cream);outline:none}
.web-form .field:focus{border-color:var(--coral);background:#fff}
.web-form .btn-p{width:100%;justify-content:center}
@media(max-width:720px){.web-card{grid-template-columns:1fr;gap:22px}}

.cta{background:var(--cream)}
.cta .card{background:var(--indigo);color:#fff;border-radius:34px;padding:clamp(36px,5vw,60px);text-align:center;position:relative;overflow:hidden}
.cta .blob{position:absolute;width:340px;height:340px;border-radius:50%;background:rgba(244,166,61,.14);top:-140px;right:-70px}
.cta .in{position:relative;z-index:1}
.cta h2{font-family:'Baloo 2';font-size:clamp(24px,3.6vw,38px);color:#fff;max-width:24ch;margin-inline:auto}
.cta p{font-size:16.5px;color:rgba(255,255,255,.78);margin:14px auto 24px;max-width:52ch}

/* related */
.related{background:var(--cream-2)}
.rel-grid{margin-top:30px;display:grid;grid-template-columns:repeat(4,1fr);gap:14px}
.rc{background:#fff;border-radius:16px;padding:20px 22px;transition:transform .2s,box-shadow .2s;border:1px solid transparent}
.rc:hover{transform:translateY(-3px);box-shadow:0 12px 28px rgba(58,47,40,.08);border-color:var(--apricot-2)}
.rc h3{font-family:'Baloo 2';font-size:16px;color:var(--indigo)}.rc p{font-size:13px;color:var(--ink-2);margin-top:3px}
@media(max-width:860px){.rel-grid{grid-template-columns:1fr 1fr}}

</style>
<div class="wrap crumb"><a href="/">Home</a> › <a href="/#offer">What we offer</a> › <span>Light therapy</span></div>

<header class="hero spots">
  <span class="blob"></span>
  <div class="wrap hero-in">
    <span class="eyebrow">The Lights On™ Pathways Method · ~5 min read</span>
    <h1>Photobiomodulation, light therapy &amp; laser therapy for children</h1>
    <p class="lede">If you've come across the term <b>photobiomodulation</b> — or its more familiar names, low-level light therapy (LLLT), laser light therapy, or cold laser therapy — you may be wondering what it is, whether it's safe for children, whether it can help with autism, and how it fits alongside speech and language therapy. Here's a straightforward guide to our Lights On Pathways Method.</p>
    <div class="hero-cta">
      <a class="btn btn-p" href="/book-an-appointment/">Book an appointment</a>
      <a class="btn btn-w" href="#webinar">Join the free webinar</a>
    </div>
    <div class="hero-pills">
      <span class="hp">Non-invasive · no heat, no pain</span>
      <span class="hp">Always alongside speech &amp; language therapy</span>
      <span class="hp">Clinically supervised</span>
    </div>
  </div>
</header>

<section class="article">
  <div class="wrap art-body">
    <h2>What is photobiomodulation?</h2>
    <p>Photobiomodulation (PBM) uses specific wavelengths of red and near-infrared light, delivered at a low, gentle intensity, to the body or head. It doesn't produce heat, and it's also known as low-level light therapy (LLLT), low-level laser therapy, cold laser therapy, and red, green, violet and near-infrared light therapy.</p>
    <p>These terms are often used loosely to mean the same thing, but there's an important technical difference worth knowing: some devices deliver light using LEDs (light-emitting diodes), while others use a true laser — a different light source. <b>Lights On uses genuine laser technology, not LEDs.</b></p>
    <p>Unlike surgical or cosmetic lasers, PBM devices work at gentle levels that don't cut, burn, or damage skin. Sessions are comfortable and non-invasive. As part of the Lights On Pathways Method, treatment time is used actively — light is delivered while your child works on motor or speech and language tasks, so the session doubles as useful therapy time.</p>

    <h2>The Lights On Pathways Method</h2>
    <p>Photobiomodulation is offered as an extra, supportive approach alongside — not a replacement for — proven speech and language therapy. Every child's plan is worked out specifically for them and carried out under clinical supervision, separate from standard HCPC/RCSLT-regulated speech and language therapy.</p>
    <p>The name "Pathways" reflects how the nervous system works: as a network carrying signals between the brain, body, and gut, rather than one isolated site. That's why treatment isn't limited to the head — Hulya may also work with the body and digestive system, depending on what's relevant for that child.</p>
    <p>A wide range of areas may be considered when building a plan, including late talking, expressive language, sleep, sensory-related feeding patterns, memory, emotional regulation, motor coordination, and behaviour. These inform the plan; PBM is never presented as proven to fix them, and it's never used alone or as a first port of call. It's one part of a wider plan, alongside direct speech and language therapy and, where relevant, your GP or other professionals.</p>
    <p>This whole-body thinking also covers the gut-brain connection — a genuinely active area of research into how the gut and brain communicate. To build a fuller picture, Hulya may also draw on functional lab testing from one of the world's leading specialist labs. This isn't used to diagnose anything; it's one extra source of information feeding into the plan, alongside clinical observation and, where appropriate, your GP.</p>

    <h2>Led by advanced, hands-on experience</h2>
    <div class="author">
      <div class="ph"><img src="https://articulatekids.co.uk/wp-content/uploads/2025/07/2F1A9461-1-2-683x1024.jpg" alt="Hulya Mehmet"></div>
      <div>
        <h3>Hulya Mehmet</h3>
        <div class="role">Consultant Speech &amp; Language Therapist · BSc (Hons), MRCSLT</div>
        <p>The Lights On Pathways Method is led by Hulya Mehmet, with over 25 years of clinical experience and the first, leading practitioner in the UK to bring advanced photobiomodulation expertise into work with children. She has completed hundreds of hours of hands-on PBM sessions, and refines her approach as a core, actively-practised part of her work. Hulya is regularly asked to act as an Expert Witness in SEND Tribunal cases and EHCP assessments across England and Wales, and is the author of <b>Why Isn't My Child Talking?</b> Her BSc (Hons) in Clinical Communication Science from City University (2001) covered neuroscience, linguistics, phonetics, and behavioural psychology, and still informs how she works today.</p>
      </div>
    </div>

    <h2>Light therapy and autism: what the research says</h2>
    <p>Many families come to Lights On searching specifically for light or laser therapy for autism and ADHD — a fair question that deserves a straight answer.</p>
    <p>This is a genuinely active area of scientific interest. Several small studies have looked at whether light applied to the head (sometimes called transcranial photobiomodulation) may be linked to changes in attention, behaviour, sleep, and communication in autistic children, with some encouraging early findings. But the evidence is still at an early stage — these are relatively smaller studies, larger trials are needed, and <b>photobiomodulation is not a recognised cure or stand-alone treatment for autism.</b> Our Lights On Method is always offered as one part of a wider, individually considered plan, alongside speech and language therapy.</p>

    <h2>What does a session involve?</h2>
    <ul>
      <li>A brief settling-in period</li>
      <li>Light applied to targeted areas for a set time, based on your child's plan</li>
      <li>No pain, heat, or sedation — your child stays actively involved, often working on motor or speech tasks during the session</li>
      <li>Ongoing review of progress alongside your child's wider therapy plan</li>
    </ul>
    <div class="callout">Progress typically happens quickly. Early signs are often seen after the first session or two, with more noticeable progress typically by around session five, and progress often continuing after treatment is stopped. Lights On is offered as an initial block of ten sessions. <b>This is what we typically observe and what parents and teachers often report, but individual results can vary and are never guaranteed.</b></div>

    <h2>Is it safe?</h2>
    <p>PBM devices follow specific safety limits, and each plan is worked out individually — factoring in things like age and weight — rather than applied the same way to everyone. Lights On uses top-of-range, FDA-cleared medical laser devices, and every plan is developed and reviewed under clinical supervision.</p>
    <p>If you're considering PBM for your child, it's worth asking any provider: who oversees the plan and what are their qualifications, how is the amount of light worked out for your child, how does it fit with existing therapies, and what progress is being tracked?</p>

    <p class="disclaimer">This page is for general information only and is not a substitute for individual clinical advice. Please speak with a qualified professional about your child's specific needs.</p>
  </div>
</section>

<section class="faq" id="faq">
  <div class="wrap narrow" style="margin-inline:auto">
    <h2 class="ba" style="font-size:clamp(24px,3.4vw,34px);color:var(--indigo);text-align:center;font-weight:800">Quick answers</h2>
    <div class="faq-wrap">
      <div class="fi"><button class="fq" onclick="tf(this)">Is red light therapy the same as laser therapy?<span class="t">+</span></button><div class="faq-a">No — the two are often confused, but they're not the same thing. Red light therapy typically uses LEDs (light-emitting diodes), while laser therapy uses a true laser, a different light source with its own distinct properties. Lights On uses genuine laser technology, not LEDs.</div></div>
      <div class="fi"><button class="fq" onclick="tf(this)">Can it help autistic children?<span class="t">+</span></button><div class="faq-a">Early research shows promise, but it's not a proven cure and should only be used as part of a wider plan alongside established therapies.</div></div>
      <div class="fi"><button class="fq" onclick="tf(this)">Does it replace speech and language therapy?<span class="t">+</span></button><div class="faq-a">No — it's always offered alongside, never instead of.</div></div>
    </div>
  </div>
</section>

<section class="webinar" id="webinar">
  <div class="wrap">
    <div class="web-card">
      <div>
        <span class="free">FREE</span>
        <h2>Free monthly webinar for parents</h2>
        <p>Each month, Hulya runs a free webinar for parents on the gut-brain connection, sensory regulation, mood, and childhood development. Open to anyone, no fee.</p>
        <div class="web-when">📅 First Thursday of every month · 8pm (London time)</div>
      </div>
      <div class="web-form">
        <input class="field" type="text" placeholder="First name">
        <input class="field" type="email" placeholder="Email address">
        <button class="btn btn-p">Save my seat</button>
      </div>
    </div>
  </div>
</section>

<section class="related">
  <div class="wrap">
    <span class="eyebrow" style="display:inline-flex;margin-bottom:0">Explore</span>
    <div class="rel-grid">
      <a class="rc" href="/conditions-help/autism/"><h3>Autism</h3><p>Communication, social and sensory needs.</p></a>
      <a class="rc" href="/conditions-help/adhd/"><h3>ADHD</h3><p>Where attention and language meet.</p></a>
      <a class="rc" href="/conditions-help/early-years-late-talkers/"><h3>Late talkers</h3><p>Early support that matters most.</p></a>
      <a class="rc" href="/#offer"><h3>What we offer</h3><p>Assessment, therapy, testing and more.</p></a>
    </div>
  </div>
</section>

<section class="cta">
  <div class="wrap">
    <div class="card"><span class="blob"></span>
      <div class="in">
        <h2>Wondering if a combined approach is right for your child?</h2>
        <p>We're happy to talk you through our speech and language therapy and the Lights On™ Pathways Method — what's involved, what to expect, and what the evidence does and doesn't say.</p>
        <a class="btn btn-p" style="background:var(--amber)" href="/book-an-appointment/">Talk to us</a>
      </div>
    </div>
  </div>
</section>

<script type="application/ld+json">
{"@context":"https://schema.org","@type":"FAQPage","mainEntity":[
{"@type":"Question","name":"Is red light therapy the same as laser therapy?","acceptedAnswer":{"@type":"Answer","text":"No. Red light therapy typically uses LEDs (light-emitting diodes), while laser therapy uses a true laser, a different light source with its own distinct properties. Lights On uses genuine laser technology, not LEDs."}},
{"@type":"Question","name":"Can light therapy help autistic children?","acceptedAnswer":{"@type":"Answer","text":"Early research shows promise, but it is not a proven cure and should only be used as part of a wider plan alongside established therapies."}},
{"@type":"Question","name":"Does light therapy replace speech and language therapy?","acceptedAnswer":{"@type":"Answer","text":"No. It is always offered alongside, never instead of speech and language therapy."}}
]}
</script>
<script type="application/ld+json">
{"@context":"https://schema.org","@type":"MedicalWebPage","name":"Photobiomodulation, light therapy & laser therapy for children","about":"Photobiomodulation (light therapy) for children with autism, ADHD and communication difficulties","author":{"@type":"Person","name":"Hulya Mehmet","jobTitle":"Consultant Speech and Language Therapist","alumniOf":"City University","hasCredential":"BSc (Hons) Clinical Communication Science; MRCSLT","knowsAbout":["Photobiomodulation","Speech and Language Therapy","Autism","ADHD","Neurodiversity"]}}
</script>

<?php get_footer();

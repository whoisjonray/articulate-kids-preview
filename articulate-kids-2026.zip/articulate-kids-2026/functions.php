<?php
if (!defined('ABSPATH')) exit;

add_action('after_setup_theme', function () {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', ['search-form','gallery','caption','style','script']);
    register_nav_menus(['primary' => 'Primary Menu', 'footer_where' => 'Footer: Where we help', 'footer_what' => 'Footer: What we do', 'footer_start' => 'Footer: Get started']);
});

add_action('wp_enqueue_scripts', function () {
    $v = wp_get_theme()->get('Version');
    wp_enqueue_style('ak-fonts', 'https://fonts.googleapis.com/css2?family=Baloo+2:wght@500;600;700;800&family=Nunito:wght@400;500;600;700&display=swap', [], null);
    wp_enqueue_style('ak-main', get_stylesheet_directory_uri() . '/assets/css/main.css', [], $v);
    wp_enqueue_script('ak-main', get_stylesheet_directory_uri() . '/assets/js/main.js', [], $v, true);
});

// Preconnect for fonts
add_filter('wp_resource_hints', function ($hints, $relation) {
    if ('preconnect' === $relation) { $hints[] = 'https://fonts.gstatic.com'; }
    return $hints;
}, 10, 2);

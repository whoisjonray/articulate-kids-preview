<footer>
  <div class="wrap">
    <div class="foot-cols">
      <div class="foot-brand">
        <img src="https://articulatekids.co.uk/wp-content/uploads/2022/05/cropped-articulate-kids.png" alt="Articulate Kids">
        <p>Specialist neurodevelopmental clinic for children. Orpington &amp; Harley Street, London.</p>
      </div>
      <div>
        <h4>Where we help</h4>
        <a href="https://articulatekids.co.uk/speech-therapist-orpington/">Speech therapist Orpington</a>
        <a href="https://articulatekids.co.uk/speech-therapist-harley-street/">Speech therapist Harley Street</a>
        <a href="https://articulatekids.co.uk/speech-therapist-london/">Speech therapist London</a>
        <a href="https://articulatekids.co.uk/speech-therapist-bromley/">Speech therapist Bromley</a>
        <a href="https://articulatekids.co.uk/speech-therapist-dartford/">Speech therapist Dartford</a>
      </div>
      <div>
        <h4>What we do</h4>
        <a href="https://articulatekids.co.uk/services/">Our services</a>
        <a href="https://articulatekids.co.uk/conditions-help/">Conditions we treat</a>
        <a href="https://articulatekids.co.uk/ehcp-tribunal-expert/">EHCP &amp; tribunals</a>
        <a href="https://articulatekids.co.uk/articles/">Articles for parents</a>
        <a href="https://articulatekids.co.uk/what-to-expect/">What to expect</a>
      </div>
      <div>
        <h4>Get started</h4>
        <a href="https://articulatekids.co.uk/book-an-appointment/">Book an appointment</a>
        <a href="https://articulatekids.co.uk/about/">About Hulya</a>
        <a href="https://articulatekids.co.uk/faq/">FAQ</a>
        <a href="https://articulatekids.co.uk/location/">Find us</a>
        <a href="tel:02038580765">020 3858 0765</a>
      </div>
    </div>
    <div class="foot-bottom">
      <span>© Articulate Kids · Specialist neurodevelopmental clinic, Orpington &amp; Harley Street, London</span>
      <span>020 3858 0765 · info@articulatekids.co.uk</span>
    </div>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>

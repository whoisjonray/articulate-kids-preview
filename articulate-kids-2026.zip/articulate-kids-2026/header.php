<?php if (!defined('ABSPATH')) exit; ?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<nav>
  <div class="nav-in">
    <a class="brand" href="#"><img src="https://articulatekids.co.uk/wp-content/uploads/2022/05/cropped-articulate-kids.png" alt="Articulate Kids" class="logo-img"></a>
    <div class="nav-links">
      <a href="#signs">Is this your child?</a>
      <a href="#offer">What we offer</a>
      <a href="#founder">Meet Hulya</a>
      <a href="#faq">FAQ</a>
    </div>
    <div class="nav-right">
      <span class="nav-phone">020 3858 0765</span>
      <a class="nav-cta" href="#">Book an appointment</a>
    </div>
  </div>
</nav>

<?php
/**
 * Real 5-star Google reviews (deduped from the client's export, 2026-08-12).
 * Single source of truth for the /reviews/ page AND the pull-quote callouts
 * dropped across the site. Only 5-star reviews are included (Jon: 4.5+ only).
 */
if (!defined('ABSPATH')) exit;

function ak_reviews_all() {
    return [
        ['name'=>'Jutta Gesson','date'=>'34 weeks ago','text'=>"We cannot recommend Hulya highly enough. From the outset, she was compassionate, professional, and very aware of how stressful this process can be for parents. She helped make the assessment and reporting process feel clearer and more manageable. Hulya truly listened to our concerns and took the time to understand our son as a whole person, carefully considering his challenges, strengths, and weaknesses, not just his areas of difficulty. Her assessment was thorough, and her report is exceptionally detailed, clear, and very well written. We are extremely grateful to have worked with Hulya and would wholeheartedly recommend her to other families."],
        ['name'=>'Dino Pornaris','date'=>'34 weeks ago','text'=>"I cannot speak highly enough about Hulya. From start to finish she was professional, kind, empathetic and always available to answer any questions. I am so grateful for her attention to detail and how comprehensive our report was, relating to our child's needs. I would highly recommend Hulya for speech therapy, or if you are looking for an expert to assist in your child's EHCP."],
        ['name'=>'Liesel Cleaver','date'=>'50 weeks ago','text'=>"Our son has been working with Hulya for almost 2 years now and I can't believe how lucky we are to have found her. The changes we have seen in our son have been astounding and I believe a lot of this is down to Hulya's expertise. 2 years ago, Jack wasn't able to say many words at all but is now able to make requests, engage with adults and children and give lots of eye contact to others. Jack is always really excited to attend his sessions with Hulya and we always notice a new influx of words afterwards. I'm so grateful to Hulya for helping our son find his words."],
        ['name'=>'Adeola Adedoyin','date'=>'Aug 2025','text'=>"My 11-year-old son began seeing Hulya in February of this year. He has a diagnosis of ASD, ADHD, and apraxia/verbal difficulties\u{2026}"],
        ['name'=>'Loukas Botsis','date'=>'Apr 2025','text'=>"We have been taking our son to Articulate Kids for nearly two years now. Hulya has been absolutely amazing. Our son has improved tremendously and is now fully on track and doing great at school. He has always been enjoying the sessions from day one. Hulya has been very clear and firm with her instructions and she was always right on what she recommended. Totally recommend and we have been extremely satisfied!"],
        ['name'=>'Chidinma Igboko','date'=>'Apr 2025','text'=>"We have been seeing Hulya for speech therapy for my daughter, who has a social communication disorder, and I cannot express enough how grateful we are for her. When we first started, my daughter had no way of communicating and would often become frustrated\u{2026}"],
        ['name'=>'S Usman','date'=>'Jul 2023','text'=>"Our 5 year old son started stammering at the age of 3. It was very heart breaking to see our little one struggling to get his words out. We tried different things without any improvement and started to get really frustrated. We then got to know about Hulya and her speech and language services. We started taking sessions on a weekly basis and noticed a remarkable difference in just a couple of weeks. Our son has remained consistently fluent and his self confidence has markedly increased. We are very thankful to Hulya and highly recommend her services."],
        ['name'=>'Natasha Sargeant','date'=>'Jun 2023','text'=>"We will be forever grateful for her expertise and experience which has aided our son to find his voice. Odin was diagnosed with verbal dyspraxia and was only able to say very few words at the age of 3. After starting speech and language therapy with Hulya and completing the homework provided, he has progressed immensely and is now able to talk and be understood by others in under 1 year. Hulya is confident and takes an individualised approach which my son gravitated towards. I would recommend this service to anyone that has a speech or sound disorder."],
        ['name'=>'Katell Gamlath','date'=>'Mar 2023','text'=>"Very grateful to have had the pleasure of watching Hulya work with my son over the past year. She is extremely professional and experienced and N really enjoys his sessions with her. We noticed a great improvement in his speech and social skills and it's been great to see our son progress and also gain in confidence."],
        ['name'=>'Simon Nash','date'=>'Feb 2023','text'=>"My 5 year old son had quite severe speech challenges which was not only affecting his own confidence but was having an impact at school. After a lot of searching on the internet I came across Articulate Kids and spoke with Hulya about our son's challenges. The sessions and techniques used has transformed our son from one word answers to complete sentences. I am truly thankful for all the help, patience, coaching and support and could not recommend her highly enough."],
        ['name'=>'Graham Hobson','date'=>'Sep 2022','text'=>"Hulya has been outstanding. Quick to identify the issues that needed to be addressed with my daughter's speech and then implemented an effective plan which started to produce results quickly. Hulya always provides clear guidance and resources so we can continue the work throughout the week at home. My daughter's speech has improved significantly and this has had a direct impact on her confidence as well. Both my wife and I are glad we made the decision to work with Hulya."],
        ['name'=>'Angela Lee','date'=>'May 2022','text'=>"Hulya has done an amazing job with my nearly 4 year old daughter. She was very patient and my daughter warmed to her very quickly. Her speech has come on so much and I would not hesitate to recommend Hulya to anyone looking for a speech and language therapist."],
    ];
}

/* Short, punchy pull-quotes for callout boxes across the site (all from real 5-star reviews above). */
function ak_review_pullquotes() {
    return [
        ['q'=>"The changes we have seen in our son have been astounding.",'name'=>'Liesel Cleaver'],
        ['q'=>"Hulya has been absolutely amazing. Our son has improved tremendously and is now fully on track.",'name'=>'Loukas Botsis'],
        ['q'=>"We cannot recommend Hulya highly enough.",'name'=>'Jutta Gesson'],
        ['q'=>"She has aided our son to find his voice. He is now able to talk and be understood by others in under 1 year.",'name'=>'Natasha Sargeant'],
        ['q'=>"Transformed our son from one word answers to complete sentences.",'name'=>'Simon Nash'],
        ['q'=>"I cannot speak highly enough about Hulya.",'name'=>'Dino Pornaris'],
    ];
}

/* Render a single review pull-quote callout box. $i selects which quote (rotates). */
function ak_review_pullquote($i = 0) {
    $q = ak_review_pullquotes();
    $r = $q[$i % count($q)];
    return '<figure class="rq"><div class="rq-stars" aria-label="Rated 5 out of 5">&#9733;&#9733;&#9733;&#9733;&#9733;</div>'
         . '<blockquote>' . esc_html($r['q']) . '</blockquote>'
         . '<figcaption>' . esc_html($r['name']) . ' <span>&middot; Google review</span></figcaption></figure>';
}

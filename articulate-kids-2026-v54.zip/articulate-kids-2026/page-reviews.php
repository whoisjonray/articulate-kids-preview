<?php
/**
 * Reviews page (was /testimonials/, now /reviews/).
 *
 * Built to read like a Google/Trustpilot review page: an aggregate-rating header
 * with a big star score, then reviews stacked full-width with an avatar initial,
 * name, star row and date. Carries AggregateRating + Review schema (JSON-LD) so
 * Google can show the ★ rating in search results — the actual SEO win here, since
 * "reviews" keywords have no measurable UK search volume. H1 is anchored on the
 * service + location terms that DO rank.
 */
if (!defined('ABSPATH')) exit;

$ak_reviews = ak_reviews_all();
$ak_count   = count($ak_reviews);

// star colours for avatar circles
$ak_colours = ['#3B3684','#E56B47','#524CA0','#C9893D','#2A2660','#D25938'];

get_header(); ?>

<?php
// --- Review + AggregateRating schema for star snippets in Google ---
$ak_schema = [
    '@context' => 'https://schema.org',
    '@type'    => 'LocalBusiness',
    'name'     => 'Articulate Kids Speech and Language Therapy',
    'url'      => 'https://articulatekids.co.uk/',
    'telephone'=> '020 3858 0765',
    'address'  => ['@type'=>'PostalAddress','addressLocality'=>'Orpington','addressRegion'=>'Kent','addressCountry'=>'GB'],
    'aggregateRating' => ['@type'=>'AggregateRating','ratingValue'=>'5.0','reviewCount'=>(string)$ak_count,'bestRating'=>'5'],
    'review' => array_map(function ($r) {
        return [
            '@type'  => 'Review',
            'author' => ['@type'=>'Person','name'=>$r['name']],
            'reviewRating' => ['@type'=>'Rating','ratingValue'=>'5','bestRating'=>'5'],
            'reviewBody' => $r['text'],
        ];
    }, $ak_reviews),
];
echo '<script type="application/ld+json">' . wp_json_encode($ak_schema) . '</script>';
?>

<div class="revpage">
  <div class="wrap">

    <header class="rev-head">
      <h1>Speech and Language Therapy Reviews</h1>
      <div class="rev-agg">
        <div class="rev-agg-score">5.0</div>
        <div>
          <div class="rev-agg-stars" aria-label="Rated 5 out of 5">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
          <div class="rev-agg-count"><?php echo (int) $ak_count; ?> five-star reviews from families we've worked with</div>
        </div>
      </div>
      <p class="rev-sub">Real reviews from parents across Orpington, London and Kent. Every family here came to Hulya worried about their child. Here's what they say now.</p>
      <a class="btn btn-p" href="/book-an-appointment/">Book an assessment</a>
    </header>

    <div class="rev-list">
      <?php foreach ($ak_reviews as $i => $r) :
          $initial = mb_strtoupper(mb_substr($r['name'], 0, 1));
          $colour  = $ak_colours[$i % count($ak_colours)];
      ?>
        <article class="rev-item">
          <div class="rev-avatar" style="background:<?php echo esc_attr($colour); ?>" aria-hidden="true"><?php echo esc_html($initial); ?></div>
          <div class="rev-body">
            <div class="rev-meta">
              <span class="rev-name"><?php echo esc_html($r['name']); ?></span>
              <span class="rev-date"><?php echo esc_html($r['date']); ?></span>
            </div>
            <div class="rev-stars" aria-label="Rated 5 out of 5">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
            <p class="rev-text"><?php echo esc_html($r['text']); ?></p>
          </div>
        </article>
      <?php endforeach; ?>
    </div>

    <section class="rev-cta">
      <h2>Ready to find out what's going on with your child?</h2>
      <p>No waiting list, no referral needed. Start with an assessment, or come to Hulya's free monthly webinar first.</p>
      <div class="rev-cta-btns">
        <a class="btn btn-p" href="/book-an-appointment/">Book an assessment</a>
        <a class="btn btn-w" href="/#webinar">See the free webinar</a>
      </div>
    </section>

  </div>
</div>

<?php get_footer(); ?>

<?php
/**
 * Generic page template.
 *
 * City pages (.ak-hub-page) and condition pages (.page-content) carry their own
 * <h1> inside post_content. Printing the_title() as an <h1> here as well gave
 * every one of those pages two H1s. So the title is only printed when the
 * content doesn't already supply one, which also preserves each page's existing
 * heading structure exactly as it was before the migration.
 */
if (!defined('ABSPATH')) exit;
get_header(); ?>

<?php while (have_posts()) : the_post(); ?>
<?php
    $ak_content    = apply_filters('the_content', get_the_content());
    $ak_has_own_h1 = (bool) preg_match('/<h1[\s>]/i', $ak_content);
    // Self-contained layouts style themselves; everything else gets the article shell.
    $ak_self_styled = (bool) preg_match('/class="[^"]*\b(ak-hub-page|page-content)\b/i', $ak_content);
?>

  <?php if ($ak_self_styled) : ?>

    <article><?php echo $ak_content; ?></article>

  <?php else : ?>

    <article class="wrap entry-wrap">
      <?php if (!$ak_has_own_h1) : ?>
        <div class="entry-head"><h1><?php the_title(); ?></h1></div>
      <?php endif; ?>
      <div class="prose entry-content"><?php echo $ak_content; ?></div>
    </article>

  <?php endif; ?>

<?php endwhile; ?>

<?php get_footer();

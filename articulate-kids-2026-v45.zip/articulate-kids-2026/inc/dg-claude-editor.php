<?php
// DoorGrow - Claude AI Editor Meta Box
// Standalone Code Snippet version - no plugin dependencies

if (!class_exists('DG_Claude_Editor_Standalone')) {
class DG_Claude_Editor_Standalone {
    private static $instance = null;
    public static function instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }
    private function __construct() {
        add_action('add_meta_boxes', array($this, 'add_metabox'));
        add_action('admin_footer', array($this, 'inline_js'));
        add_action('rest_api_init', array($this, 'register_settings_route'));
        // Custom auth header support for Flywheel hosting
        add_filter('determine_current_user', array($this, 'handle_custom_auth'), 25);
    }

    // Accept X-WP-Auth header as alternative to Authorization (Flywheel strips it)
    public function handle_custom_auth($user_id) {
        if ($user_id) return $user_id;
        $auth = isset($_SERVER['HTTP_X_WP_AUTH']) ? $_SERVER['HTTP_X_WP_AUTH'] : '';
        if (empty($auth)) return $user_id;
        $decoded = base64_decode($auth);
        if (!$decoded || strpos($decoded, ':') === false) return $user_id;
        list($username, $password) = explode(':', $decoded, 2);
        $user = wp_authenticate_application_password(null, $username, $password);
        if (is_wp_error($user)) return $user_id;
        return $user->ID;
    }

    // Settings REST route for configuring credentials
    public function register_settings_route() {
        register_rest_route('dg-claude/v1', '/config', array(
            array('methods' => 'GET', 'callback' => array($this, 'get_config'), 'permission_callback' => function() { return current_user_can('manage_options'); }),
            array('methods' => 'POST', 'callback' => array($this, 'set_config'), 'permission_callback' => function() { return current_user_can('manage_options'); }),
        ));
    }
    public function get_config() {
        $config = get_option('dg_claude_editor_config', array());
        unset($config['app_password']); // never expose password in GET
        return rest_ensure_response($config);
    }
    public function set_config($request) {
        $body = $request->get_json_params();
        $config = get_option('dg_claude_editor_config', array());
        $allowed = array('username', 'app_password', 'ssh_host', 'theme_dir');
        foreach ($allowed as $key) {
            if (isset($body[$key])) $config[$key] = sanitize_text_field($body[$key]);
        }
        update_option('dg_claude_editor_config', $config);
        return rest_ensure_response(array('success' => true));
    }

    public function add_metabox() {
        add_meta_box('dg_claude_editor', 'Edit with Claude AI', array($this, 'render_metabox'), 'page', 'normal', 'high');
    }

    public function render_metabox($post) {
        $prompt = $this->generate_prompt($post);
        $config = get_option('dg_claude_editor_config', array());
        $has_creds = !empty($config['username']) && !empty($config['app_password']);
        ?>
        <div class="dg-claude-editor-wrap">
            <?php if (!$has_creds) : ?>
                <div style="background:#fff3cd; border-left:4px solid #ffc107; padding:12px 16px; margin-bottom:16px;">
                    <strong>Setup needed:</strong> Run this WP-CLI command or use the REST API to configure credentials:<br>
                    <code>wp option update dg_claude_editor_config '{"username":"...","app_password":"...","ssh_host":"...","theme_dir":"..."}' --format=json</code>
                </div>
            <?php endif; ?>
            <div style="margin-bottom:16px;">
                <p style="font-size:14px; margin:0 0 8px;"><strong>How to edit this page with Claude Desktop:</strong></p>
                <ol style="margin:0 0 16px; padding-left:20px; font-size:13px; color:#555; line-height:1.7;">
                    <li>Copy the prompt below</li>
                    <li>Open <strong>Claude Desktop</strong> and paste it to start a new conversation</li>
                    <li>Tell Claude what you'd like to change, or take a <strong>screenshot</strong> of the section you want edited and paste it alongside your request</li>
                    <li>Claude will make the edit via the API &mdash; refresh this page to see the change</li>
                </ol>
            </div>
            <div style="position:relative;">
                <textarea id="dg-claude-prompt" readonly style="width:100%; min-height:300px; font-family:monospace; font-size:12px; padding:16px; background:#f6f7f7; border:1px solid #ddd; border-radius:4px; resize:vertical; line-height:1.6;"><?php echo esc_textarea($prompt); ?></textarea>
                <button type="button" id="dg-copy-prompt" class="button button-primary" style="position:absolute; top:8px; right:8px; z-index:10;">Copy Prompt</button>
            </div>
            <div style="margin-top:16px; padding:12px 16px; background:#f0f6fc; border-left:4px solid #2271b1; font-size:13px; line-height:1.6;">
                <strong>Screenshot tip:</strong> For precise edits, take a screenshot of the exact section on the live site you want changed. In Claude Desktop, paste the screenshot along with something like: <em>"Change the headline in this screenshot to 'Your New Headline Here'"</em>
            </div>
            <details style="margin-top:12px;">
                <summary style="cursor:pointer; font-size:13px; font-weight:600; color:#2271b1;">&blacktriangleright; Example prompts you can try</summary>
                <div style="padding:12px 0; font-size:13px; color:#555; line-height:1.8;">
                    <?php echo $this->get_example_prompts($post); ?>
                </div>
            </details>
        </div>
        <?php
    }

    public function generate_prompt($post) {
        $site_url = home_url();
        $config = get_option('dg_claude_editor_config', array());
        $username = $config['username'] ?? '[USERNAME]';
        $app_password = $config['app_password'] ?? '[APP_PASSWORD]';
        $auth_header = base64_encode($username . ':' . $app_password);
        $ssh_host = $config['ssh_host'] ?? '';
        $theme_dir = $config['theme_dir'] ?? '';
        $page_id = $post->ID;
        $is_front = (int)get_option('page_on_front') === (int)$page_id;

        $p = "You are helping me edit my property management website. Here's everything you need.\n\n";

        // REST API Access
        $p .= "== REST API ACCESS ==\n";
        $p .= "Site: {$site_url}\n";
        $p .= "For all API calls, use BOTH of these headers:\n";
        $p .= "X-WP-Auth: {$auth_header}\n";
        $p .= "Content-Type: application/json\n";
        $p .= "(This site uses a custom auth header because the hosting strips standard Authorization headers.)\n\n";

        // SSH
        if ($ssh_host) {
            $p .= "== SSH ACCESS (for editing theme template files) ==\n";
            $p .= "SSH: ssh -o ConnectTimeout=15 {$ssh_host}\n";
            if ($theme_dir) $p .= "Theme files: /www/wp-content/themes/{$theme_dir}/\n";
            $p .= "WP-CLI: cd /www && wp [command]\n";
            $p .= "Cache flush after edits: cd /www && wp cache flush\n\n";
            $p .= "USE SSH WHEN:\n";
            $p .= "- Content is hardcoded in PHP template files (not editable via REST API)\n";
            $p .= "- The REST API can't reach the content (template-parts, page-templates, etc.)\n";
            $p .= "- You need to edit CSS, JS, or theme structure\n\n";
            $p .= "SSH RULES:\n";
            if ($theme_dir) {
                $p .= "- ALWAYS read the file first before editing: ssh ... \"cat /www/wp-content/themes/{$theme_dir}/path/to/file.php\"\n";
            }
            $p .= "- Use sed for simple text replacements, or write the full file for larger changes\n";
            $p .= "- After any file edit, flush the cache: ssh ... \"cd /www && wp cache flush\"\n";
            $p .= "- Preserve all PHP logic, classes, and structure - only change text content\n";
            $p .= "- Don't install plugins, change themes, or modify wp-config.php\n\n";
        }

        // Current page context
        $p .= $this->page_context($post, $site_url, $is_front);

        // All pages
        $p .= $this->all_pages_context($site_url, $page_id);

        // Rules
        $p .= "== RULES ==\n";
        $p .= "- ALWAYS read the current content with a GET request before making changes\n";
        $p .= "- Only change what I specifically ask you to change\n";
        $p .= "- When editing HTML content, preserve the existing structure and classes - only change text inside tags\n";
        $p .= "- Use contractions (don't, won't, we're) - this is how the site is written\n";
        $p .= "- Never use em dashes - use periods, commas, or colons instead\n";
        $p .= "- After making a change, tell me what you changed and show me the new text\n\n";

        $p .= "== SCREENSHOTS ==\n";
        $p .= "I may paste screenshots of specific sections I want edited. When I do:\n";
        $p .= "1. Identify which section/field the screenshot corresponds to\n";
        $p .= "2. Try the REST API first (GET the content, find the matching text)\n";
        $p .= "3. If the content isn't in the API response, it's in a PHP template - use SSH to find and edit it\n";
        $p .= "4. Make the change and confirm what was changed\n\n";

        $p .= "I'm ready. What would you like me to help you edit?";
        return $p;
    }

    private function page_context($post, $site_url, $is_front) {
        $id = $post->ID;
        $title = $post->post_title;
        $template = get_page_template_slug($id);
        $content = $post->post_content;
        $has_content = !empty(trim($content));

        if ($is_front) {
            $ctx = "== THIS PAGE: HOMEPAGE (ID: {$id}) ==\n";
        } else {
            $ctx = "== THIS PAGE: {$title} (ID: {$id}) ==\n";
        }

        if ($template) $ctx .= "Template: {$template}\n";

        if ($has_content) {
            $ctx .= "This page stores its content as HTML in WordPress.\n";
            $ctx .= "To read: GET {$site_url}/wp-json/wp/v2/pages/{$id}\n";
            $ctx .= "To update: POST {$site_url}/wp-json/wp/v2/pages/{$id}\n";
            $ctx .= "Send: {\"content\": \"your updated HTML\"}\n\n";
            $ctx .= "IMPORTANT: The HTML content may be minified. When updating:\n";
            $ctx .= "- Read the full content first with a GET request\n";
            $ctx .= "- Find the specific text you need to change\n";
            $ctx .= "- Replace only that text, keeping all HTML structure, classes, and inline styles intact\n";
            $ctx .= "- Send the complete updated HTML back (not just the changed section)\n\n";
            $plain = wp_strip_all_tags($content);
            if (strlen($plain) > 500) $plain = substr($plain, 0, 500) . '...';
            if (strlen(trim($plain)) > 0) $ctx .= "Current page text preview:\n\"{$plain}\"\n\n";
        } else {
            if ($template) {
                $ctx .= "This page uses a custom PHP template. Its content is hardcoded in the template file.\n";
                $ctx .= "To edit, use SSH to read and modify the template file directly.\n\n";
            } else {
                $ctx .= "This page has no content yet.\n";
                $ctx .= "To add content: POST {$site_url}/wp-json/wp/v2/pages/{$id}\n";
                $ctx .= "Send: {\"content\": \"your HTML content\"}\n\n";
            }
        }

        $ctx .= "For SEO changes, update RankMath fields:\n";
        $ctx .= "POST {$site_url}/wp-json/wp/v2/pages/{$id}\n";
        $ctx .= "Send: {\"rankmath_seo\": {\"title\": \"...\", \"description\": \"...\", \"focus_keyword\": \"...\"}}\n";
        $ctx .= "Or: {\"meta\": {\"rank_math_title\": \"...\", \"rank_math_description\": \"...\", \"rank_math_focus_keyword\": \"...\"}}\n\n";

        return $ctx;
    }

    private function all_pages_context($site_url, $current_page_id) {
        $pages = get_pages(array('sort_column' => 'menu_order', 'post_status' => 'publish'));
        if (empty($pages)) return '';
        $ctx = "== OTHER PAGES ON THIS SITE ==\n";
        $ctx .= "You can also edit other pages if I ask. Here are the available pages:\n";
        foreach ($pages as $page) {
            $marker = ($page->ID === $current_page_id) ? ' (CURRENT)' : '';
            $ctx .= "- {$page->post_title} (ID: {$page->ID}): GET/POST {$site_url}/wp-json/wp/v2/pages/{$page->ID}{$marker}\n";
        }
        $ctx .= "\n";
        return $ctx;
    }

    private function get_example_prompts($post) {
        $is_front = (int)get_option('page_on_front') === (int)$post->ID;
        if ($is_front) {
            return '<ul style="margin:0; padding-left:16px;">
                <li><em>"Change the hero headline to \'Property Management Done Right\'"</em></li>
                <li><em>"Update the phone number to (555) 123-4567"</em></li>
                <li><em>[screenshot of a section] "Make the subtext under this headline shorter and punchier"</em></li>
                <li><em>"Update the SEO title to: Company Name | City Property Management"</em></li>
            </ul>';
        }
        return '<ul style="margin:0; padding-left:16px;">
            <li><em>"Change the page title to \'Our Management Services\'"</em></li>
            <li><em>"Update the meta description for SEO to: ..."</em></li>
            <li><em>[screenshot of a section] "Replace this paragraph with: ..."</em></li>
            <li><em>"Add a new FAQ question about lease terms"</em></li>
        </ul>';
    }

    public function inline_js() {
        $screen = get_current_screen();
        if (!$screen || $screen->base !== 'post' || $screen->post_type !== 'page') return;
        ?>
        <script>
        (function(){
            document.addEventListener('DOMContentLoaded',function(){
                var btn=document.getElementById('dg-copy-prompt'),ta=document.getElementById('dg-claude-prompt');
                if(!btn||!ta)return;
                btn.addEventListener('click',function(){
                    ta.select();ta.setSelectionRange(0,99999);
                    if(navigator.clipboard&&navigator.clipboard.writeText){
                        navigator.clipboard.writeText(ta.value).then(function(){s(btn)}).catch(function(){document.execCommand('copy');s(btn)});
                    }else{document.execCommand('copy');s(btn);}
                });
                function s(b){var o=b.textContent;b.textContent='Copied!';b.style.background='#00a32a';b.style.borderColor='#00a32a';setTimeout(function(){b.textContent=o;b.style.background='';b.style.borderColor='';},2000);}
            });
        })();
        </script>
        <?php
    }
}
DG_Claude_Editor_Standalone::instance();
}

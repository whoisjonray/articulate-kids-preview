<footer>
  <div class="wrap">
    <div class="foot-news">
      <div>
        <h4>Get Hulya's parent updates</h4>
        <p>Practical guidance on children's communication, brain &amp; gut health, and the free monthly webinar. No spam, unsubscribe anytime.</p>
      </div>
      <form class="foot-news-form" onsubmit="return false">
        <input class="field" type="email" placeholder="Your email address">
        <button class="btn btn-p">Subscribe</button>
      </form>
    </div>
    <div class="foot-cols">
      <div class="foot-brand">
        <img src="https://articulatekids.co.uk/wp-content/uploads/2022/05/cropped-articulate-kids.png" alt="Articulate Kids">
        <p>Specialist neurodevelopmental clinic for children. Orpington &amp; Harley Street, London.</p>
      </div>
      <div>
        <h4>Where we help</h4>
        <a href="https://articulatekids.co.uk/speech-therapist-orpington/">Speech therapist Orpington</a>
        <a href="https://articulatekids.co.uk/speech-therapist-harley-street/">Speech therapist Harley Street</a>
        <a href="https://articulatekids.co.uk/speech-therapist-london/">Speech therapist London</a>
        <a href="https://articulatekids.co.uk/speech-therapist-bromley/">Speech therapist Bromley</a>
        <a href="https://articulatekids.co.uk/speech-therapist-dartford/">Speech therapist Dartford</a>
      </div>
      <div>
        <h4>What we do</h4>
        <a href="https://articulatekids.co.uk/services/">Our services</a>
        <a href="https://articulatekids.co.uk/conditions-help/">Conditions we treat</a>
        <a href="https://articulatekids.co.uk/ehcp-tribunal-expert/">EHCP &amp; tribunals</a>
        <a href="https://articulatekids.co.uk/articles/">Articles for parents</a>
        <a href="https://articulatekids.co.uk/what-to-expect/">What to expect</a>
      </div>
      <div>
        <h4>Get started</h4>
        <a href="https://articulatekids.co.uk/book-an-appointment/">Book an appointment</a>
        <a href="https://articulatekids.co.uk/about/">About Hulya</a>
        <a href="https://articulatekids.co.uk/faq/">FAQ</a>
        <a href="https://articulatekids.co.uk/location/">Find us</a>
        <a href="https://articulatekids.co.uk/contact/">Contact us</a>
        <a href="https://articulatekids.co.uk/testimonials/">Testimonials</a>
        <a href="tel:02038580765">020 3858 0765</a>
      </div>
    </div>
    <div class="foot-bottom">
      <span>© Articulate Kids · Specialist neurodevelopmental clinic, Orpington &amp; Harley Street, London</span>
      <span>020 3858 0765 · info@articulatekids.co.uk · <a href="https://articulatekids.co.uk/privacy-policy/">Privacy policy</a></span>
    </div>
  </div>
</footer>

<div class="webinar-pop" id="webinarPop" aria-hidden="true">
  <div class="wp-box">
    <button class="wp-close" onclick="akClosePop()" aria-label="Close">&times;</button>
    <span class="wp-free">FREE · ONLINE</span>
    <h3>Join Hulya's free monthly webinar</h3>
    <p>First Thursday of every month at 8pm. Plain-English answers on children's communication, brain &amp; gut health, and light therapy, with time for your questions.</p>
    <form class="wp-form" onsubmit="return false">
      <input class="field" type="text" placeholder="First name">
      <input class="field" type="email" placeholder="Email address">
      <button class="btn btn-p">Save my seat</button>
    </form>
    <button class="wp-dismiss" onclick="akClosePop()">No thanks</button>
  </div>
</div>
<script>
(function(){
  function show(){var p=document.getElementById("webinarPop");if(!p||localStorage.getItem("ak_webinar_pop"))return;p.classList.add("open");}
  window.akClosePop=function(){var p=document.getElementById("webinarPop");if(p)p.classList.remove("open");try{localStorage.setItem("ak_webinar_pop","1")}catch(e){}};
  setTimeout(show,18000);
  document.addEventListener("mouseout",function(e){if(e.clientY<=0)show();});
})();
</script>
<?php wp_footer(); ?>
</body>
</html>

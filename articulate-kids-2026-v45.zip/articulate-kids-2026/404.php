<?php
/**
 * 404.
 *
 * Without this, WordPress fell back to index.php and a missing URL rendered the
 * blog archive with an "Articles for parents" H1, which reads as a real page to
 * both users and crawlers.
 */
if (!defined('ABSPATH')) exit;
get_header(); ?>

<div class="wrap entry-wrap">
  <div class="entry-head">
    <h1>We can't find that page</h1>
    <p class="entry-meta">It may have moved, or the link may be wrong.</p>
  </div>
  <div class="prose" style="text-align:center">
    <p>Try the <a href="/">homepage</a>, or head straight to what you were probably after:</p>
    <p>
      <a href="/ways-to-work-with-us/">Prices and how we work</a> &nbsp;·&nbsp;
      <a href="/blog/">Articles for parents</a> &nbsp;·&nbsp;
      <a href="/book-an-appointment/">Book an assessment</a>
    </p>
    <p>Or call us on <a href="tel:02038580765">020 3858 0765</a>.</p>
  </div>
</div>

<?php get_footer();

<?php
/**
 * Single post (blog article).
 *
 * The 38 migrated posts are the site's biggest organic traffic source, so this
 * only wraps and styles them. It never alters the content or its headings.
 */
if (!defined('ABSPATH')) exit;
get_header(); ?>

<?php while (have_posts()) : the_post(); ?>
<?php
    $ak_content    = apply_filters('the_content', get_the_content());
    $ak_has_own_h1 = (bool) preg_match('/<h1[\s>]/i', $ak_content);
?>
  <article class="wrap entry-wrap">

    <div class="entry-head">
      <?php if (!$ak_has_own_h1) : ?>
        <h1><?php the_title(); ?></h1>
      <?php endif; ?>
      <div class="entry-meta"><?php echo esc_html(get_the_date('j F Y')); ?> &middot; Hulya Mehmet</div>
    </div>

    <?php if (has_post_thumbnail()) : ?>
      <div class="prose" style="margin-bottom:30px"><?php the_post_thumbnail('large'); ?></div>
    <?php endif; ?>

    <div class="prose entry-content"><?php echo $ak_content; ?></div>

    <aside class="entry-cta">
      <h2>Worried about your child's talking?</h2>
      <p>Book a free 10 minute call with Hulya, or come to the free live talk for parents. No pressure either way.</p>
      <a class="btn btn-p" href="/book-an-appointment/">Book a free 10 minute call</a>
    </aside>

    <?php
    /**
     * Popular articles. The old blog theme carried a sidebar linking the
     * highest-traffic posts on every page; the new full-width design dropped it.
     * These three posts earn ~55% of the whole site's organic traffic, so this
     * keeps the sitewide internal-link paths to them intact after migration.
     */
    $ak_popular_slugs = [
        'late-talking-signs-in-toddlers-red-flags-vs-normal-variation',
        'when-should-my-child-start-talking-age-by-age-speech-milestones',
        '18-month-old-not-talking-when-to-worry-vs-when-to-wait',
    ];
    $ak_popular = get_posts([
        'post_type'      => 'post',
        'post_name__in'  => $ak_popular_slugs,
        'post__not_in'   => [get_the_ID()],
        'posts_per_page' => 3,
        'orderby'        => 'post__in',
    ]);
    // backfill with recent posts if the current post is one of the three
    if (count($ak_popular) < 3) {
        $ak_popular = array_merge($ak_popular, get_posts([
            'post_type'      => 'post',
            'post__not_in'   => array_merge([get_the_ID()], wp_list_pluck($ak_popular, 'ID')),
            'posts_per_page' => 3 - count($ak_popular),
        ]));
    }
    if ($ak_popular) : ?>
      <section class="entry-popular">
        <h2>Popular articles</h2>
        <div class="entry-popular-grid">
          <?php foreach ($ak_popular as $ak_p) : ?>
            <a class="epc" href="<?php echo esc_url(get_permalink($ak_p)); ?>">
              <?php if (has_post_thumbnail($ak_p)) : ?>
                <span class="epc-thumb"><?php echo get_the_post_thumbnail($ak_p, 'medium', ['alt' => '']); ?></span>
              <?php else : ?>
                <span class="epc-thumb"><span class="post-card-fallback" aria-hidden="true"></span></span>
              <?php endif; ?>
              <span class="epc-title"><?php echo esc_html(get_the_title($ak_p)); ?></span>
            </a>
          <?php endforeach; ?>
        </div>
      </section>
    <?php endif; ?>

  </article>
<?php endwhile; ?>

<?php get_footer();

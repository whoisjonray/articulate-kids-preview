function tg(b){var g=b.closest('.acc-g');g.classList.toggle('open')}
function tf(b){var i=b.closest('.fi');var o=i.classList.contains('open');document.querySelectorAll('.fi').forEach(function(x){x.classList.remove('open')});if(!o)i.classList.add('open')}
function akNav(b){var m=document.getElementById('ak-nav-menu');var o=m.classList.toggle('open');b.setAttribute('aria-expanded',o?'true':'false');b.classList.toggle('open',o);}
document.addEventListener('click',function(e){
  var t=e.target.closest('.ak-menu .menu-item-has-children > a');
  if(!t||window.innerWidth>1000)return;
  e.preventDefault();t.parentNode.classList.toggle('open');
});

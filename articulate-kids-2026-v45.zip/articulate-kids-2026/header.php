<?php
/**
 * Header.
 *
 * The nav renders the site's real WordPress "Main Menu" (31 items, assigned to
 * the `primary` location) rather than a hardcoded set of links. An earlier build
 * hardcoded four on-page anchors, which silently dropped the site-wide internal
 * links to all 11 condition pages and all the location pages. Rendering the real
 * menu keeps production's link graph intact and leaves it editable in wp-admin.
 */
if (!defined('ABSPATH')) exit; ?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<nav>
  <div class="nav-in">
    <a class="brand" href="/">
      <img src="https://articulatekids.co.uk/wp-content/uploads/2022/05/cropped-articulate-kids.png" alt="Articulate Kids" class="logo-img">
      <span class="brand-desc">Speech, Language &amp; Whole-Child Development</span>
    </a>

    <button class="nav-toggle" aria-label="Menu" aria-expanded="false" onclick="akNav(this)">
      <span></span><span></span><span></span>
    </button>

    <div class="nav-menu" id="ak-nav-menu">
      <?php
      wp_nav_menu([
          'theme_location' => 'primary',
          'container'      => false,
          'menu_class'     => 'ak-menu',
          'depth'          => 3,
          'fallback_cb'    => false,
      ]);
      ?>
      <div class="nav-mob-extra">
        <a class="nav-phone-mob" href="tel:02038580765">020 3858 0765</a>
      </div>
    </div>

    <span class="nav-phone"><a href="tel:02038580765">020 3858 0765</a></span>
  </div>
</nav>

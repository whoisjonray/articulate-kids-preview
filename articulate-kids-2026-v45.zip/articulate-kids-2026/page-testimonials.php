<?php
/**
 * Testimonials.
 *
 * The stored content is a pile of legacy Divi [et_pb_testimonial] shortcodes that
 * were never closed, so the generic renderer only picked up the first one and the
 * rest fell through as loose paragraphs into a two-column grid meant for condition
 * pages. This template parses them properly (each quote runs until the next
 * shortcode) and lays them out as cards.
 */
if (!defined('ABSPATH')) exit;
get_header();

$ak_raw = get_post_field('post_content', get_the_ID());
$ak_raw = str_replace(['&#8221;', '&#8220;', '&#8243;', '”', '“'], '"', $ak_raw);

preg_match_all(
    '/\[et_pb_testimonial([^\]]*)\](.*?)(?=\[et_pb_testimonial|\z)/s',
    $ak_raw,
    $ak_matches,
    PREG_SET_ORDER
);

$ak_quotes = [];
foreach ($ak_matches as $m) {
    $attrs = $m[1];
    $body  = $m[2];

    // strip any trailing builder tags and the wrapper divs the old layout left behind
    $body = preg_replace('/\[\/?et_pb[^\]]*\]/', '', $body);
    $body = preg_replace('/<\/?div[^>]*>/', '', $body);
    $body = trim(strip_tags($body, '<p><br><strong><em>'));
    $body = trim(preg_replace('/(<p>\s*<\/p>)+/', '', $body));
    if (mb_strlen(trim(strip_tags($body))) < 40) continue;

    preg_match('/\bauthor="([^"]*)"/', $attrs, $a);
    preg_match('/\bjob_title="([^"]*)"/', $attrs, $j);
    $who = trim(($a[1] ?? '') . ((!empty($a[1]) && !empty($j[1])) ? ' · ' : '') . ($j[1] ?? ''));

    $ak_quotes[] = ['body' => $body, 'who' => $who];
}
?>

<div class="tstm">
  <div class="wrap">

    <div class="tstm-head">
      <h1>Testimonials</h1>
      <div class="tstm-stars" aria-hidden="true">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
      <p>Our service is consistently rated five stars. These are parents' own words, exactly as they sent them.</p>
    </div>

    <?php if ($ak_quotes) : ?>
      <div class="tstm-grid">
        <?php foreach ($ak_quotes as $q) : ?>
          <figure class="tstm-card">
            <div class="tstm-mark" aria-hidden="true">&ldquo;</div>
            <blockquote><?php echo wp_kses_post($q['body']); ?></blockquote>
            <?php if ($q['who']) : ?>
              <figcaption><?php echo esc_html($q['who']); ?></figcaption>
            <?php endif; ?>
          </figure>
        <?php endforeach; ?>
      </div>
    <?php else : ?>
      <div class="prose"><?php the_content(); ?></div>
    <?php endif; ?>

    <div class="tstm-cta">
      <h2>Ready to find out what's going on with your child?</h2>
      <a class="btn btn-p" href="/book-an-appointment/">Book an assessment</a>
      <p>Or call us on <a href="tel:02038580765">020 3858 0765</a>.</p>
    </div>

  </div>
</div>

<?php get_footer();
